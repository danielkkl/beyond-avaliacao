// ============================================================================
// NETLIFY FUNCTION - API Backend
// ============================================================================
// Esta função serverless roda o backend Express + tRPC no Netlify
// Compatível com Netlify Functions
// ============================================================================

import { Handler } from "@netlify/functions";
import express from "express";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { appRouter } from "../../server/routers";
import { createContext } from "../../server/_core/context";

// Criar aplicação Express
const app = express();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// CORS
app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
  res.header("Access-Control-Allow-Headers", "Content-Type, Authorization");
  
  if (req.method === "OPTIONS") {
    res.sendStatus(200);
  } else {
    next();
  }
});

// tRPC middleware
app.use(
  "/trpc",
  createExpressMiddleware({
    router: appRouter,
    createContext,
  })
);

// Health check
app.get("/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: "Not found" });
});

// Exportar como Netlify Function
export const handler: Handler = async (event, context) => {
  // Converter evento Netlify para Express request
  const req = {
    method: event.httpMethod,
    url: event.path,
    headers: event.headers,
    body: event.body ? JSON.parse(event.body) : undefined,
  };

  // Executar aplicação Express
  return new Promise((resolve) => {
    app(req as any, {
      statusCode: 200,
      setHeader: () => {},
      end: (body: string) => {
        resolve({
          statusCode: 200,
          body,
        });
      },
    } as any);
  });
};
