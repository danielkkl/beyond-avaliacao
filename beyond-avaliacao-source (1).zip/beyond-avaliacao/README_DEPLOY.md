# 🚀 Beyond Avaliação - Guia de Deploy Completo

> **Sistema profissional de avaliação fisioterapêutica SaaS - Pronto para produção no Netlify**

---

## 📌 O Que Você Tem

Um sistema completo e funcional com:

- ✅ **Frontend React** com interface profissional
- ✅ **Backend Express + tRPC** com API type-safe
- ✅ **Autenticação** com email/senha e JWT
- ✅ **Banco de dados MySQL** com schema completo
- ✅ **Pagamentos Stripe** integrados
- ✅ **Google Drive** para backup de arquivos
- ✅ **Dashboard** com estatísticas e relatórios
- ✅ **Ficha de avaliação** com 12 seções profissionais
- ✅ **Configuração Netlify** pronta para deploy

---

## 🎯 Início Rápido (5 minutos)

### 1. Clonar e Preparar

```bash
# Clone o repositório
git clone https://github.com/seu-usuario/beyond-avaliacao.git
cd beyond-avaliacao

# Instale dependências
pnpm install

# Execute o script de setup
bash SETUP_NETLIFY.sh
```

### 2. Configurar Variáveis Locais

```bash
# Copie o arquivo de exemplo
cp .env.example .env.local

# Edite com seus valores
nano .env.local
```

### 3. Testar Localmente

```bash
# Inicie o servidor de desenvolvimento
pnpm dev

# Abra http://localhost:3000
```

### 4. Deploy no Netlify

```bash
# Faça push para GitHub
git push origin main

# Netlify fará deploy automaticamente!
```

---

## 📚 Documentação Completa

| Documento | Descrição |
|-----------|-----------|
| **DEPLOY_NETLIFY.md** | Guia passo-a-passo completo para deploy |
| **CHECKLIST_DEPLOY.md** | Checklist de verificação antes de lançar |
| **TROUBLESHOOTING.md** | Soluções para problemas comuns |
| **SETUP_NETLIFY.sh** | Script automático de setup |

---

## 🔧 Configuração Necessária

### Banco de Dados (Obrigatório)

Use **Railway** ou **PlanetScale** para MySQL:

```bash
# Railway
1. Vá para https://railway.app
2. Crie novo projeto
3. Adicione MySQL
4. Copie DATABASE_URL
```

### Stripe (Obrigatório para Pagamentos)

```bash
# Stripe
1. Vá para https://stripe.com
2. Crie conta
3. Vá para API Keys
4. Copie Secret Key e Publishable Key
5. Crie webhook para seu domínio
6. Copie Webhook Secret
```

### Google Drive (Obrigatório para Premium)

```bash
# Google Cloud
1. Vá para https://console.cloud.google.com
2. Crie novo projeto
3. Ative Google Drive API
4. Crie OAuth 2.0 Client ID
5. Copie Client ID e Secret
```

### JWT Secret (Obrigatório)

```bash
# Gere uma chave aleatória
openssl rand -base64 32
```

---

## 📋 Variáveis de Ambiente

Adicione estas variáveis no **Netlify** (Site settings → Environment):

```env
# Banco de Dados
DATABASE_URL=mysql://user:pass@host:3306/database

# Stripe
STRIPE_SECRET_KEY=sk_test_...
STRIPE_PUBLISHABLE_KEY=pk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...

# Google Drive
GOOGLE_CLIENT_ID=...
GOOGLE_CLIENT_SECRET=...

# JWT
JWT_SECRET=sua_chave_aleatoria

# Node
NODE_ENV=production
```

---

## ✅ Checklist de Deploy

- [ ] Repositório criado no GitHub
- [ ] Conectado ao Netlify
- [ ] Variáveis de ambiente adicionadas
- [ ] Banco de dados criado
- [ ] Schema importado
- [ ] Stripe configurado
- [ ] Google Drive configurado
- [ ] Build bem-sucedido
- [ ] Site acessível
- [ ] Testes passando

---

## 🧪 Testes Pós-Deploy

### 1. Landing Page
```
https://seu-site.netlify.app/
```

### 2. Registro
```
1. Clique em "Registrar"
2. Preencha dados
3. Crie conta
```

### 3. Criação de Ficha
```
1. Faça login
2. Clique em "Nova Ficha"
3. Preencha dados
4. Salve
```

### 4. Pagamento
```
1. Crie 3 fichas (limite free)
2. Tente criar 4ª
3. Clique em "Upgrade"
4. Use cartão: 4242 4242 4242 4242
```

---

## 🎯 Próximos Passos

1. **Leia DEPLOY_NETLIFY.md** para instruções detalhadas
2. **Use CHECKLIST_DEPLOY.md** para verificar tudo
3. **Consulte TROUBLESHOOTING.md** se tiver problemas
4. **Execute SETUP_NETLIFY.sh** para setup automático

---

## 💡 Dicas

- ✅ Use `.env.local` para desenvolvimento (não commite!)
- ✅ Teste pagamentos com cartão `4242 4242 4242 4242`
- ✅ Monitore logs em Netlify → Deploys → Deploy log
- ✅ Faça backup do banco de dados regularmente
- ✅ Atualize dependências periodicamente

---

## 🆘 Problemas?

1. Verifique **TROUBLESHOOTING.md**
2. Verifique logs do Netlify
3. Verifique variáveis de ambiente
4. Teste localmente com `pnpm dev`

---

## 📞 Suporte

- **Netlify:** https://docs.netlify.com
- **Stripe:** https://stripe.com/docs
- **Google Drive:** https://developers.google.com/drive

---

## 🎉 Seu Sistema Está Pronto!

Tudo o que você precisa está aqui. Siga os guias e seu Beyond Avaliação estará no ar em minutos!

**Boa sorte! 🚀**

---

**Última atualização: Fevereiro 2026**
