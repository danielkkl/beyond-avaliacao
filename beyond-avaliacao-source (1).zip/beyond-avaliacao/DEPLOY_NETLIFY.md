# 🚀 Guia Completo: Deploy no Netlify

## Resumo Executivo

Este guia mostra como fazer deploy do Beyond Avaliação no Netlify com tudo pronto: frontend, backend, banco de dados, Stripe, Google Drive, tudo integrado e funcionando.

---

## 📋 Pré-requisitos

- ✅ Conta GitHub (para conectar repositório)
- ✅ Conta Netlify (https://netlify.com)
- ✅ Banco de dados MySQL (Railway, PlanetScale ou AWS)
- ✅ Conta Stripe (para pagamentos)
- ✅ Conta Google Cloud (para Google Drive)
- ✅ Domínio personalizado (opcional)

---

## 🎯 Passo 1: Preparar Repositório

### 1.1 Criar Repositório no GitHub

```bash
# 1. Criar repositório vazio no GitHub
# https://github.com/new
# Nome: beyond-avaliacao
# Descrição: Ficha de Avaliação Fisioterapêutica SaaS

# 2. Clonar repositório localmente
git clone https://github.com/seu-usuario/beyond-avaliacao.git
cd beyond-avaliacao

# 3. Adicionar arquivos do Beyond Avaliação
# Copie todos os arquivos do projeto para este diretório

# 4. Fazer commit inicial
git add .
git commit -m "Initial commit: Beyond Avaliação"
git push origin main
```

### 1.2 Verificar Estrutura

```
beyond-avaliacao/
├── client/                 # Frontend React
│   ├── src/
│   ├── dist/              # Build output
│   └── package.json
├── server/                # Backend Express
│   ├── routers.ts
│   └── _core/
├── netlify/
│   └── functions/         # Netlify Functions
├── drizzle/              # Database schema
├── netlify.toml          # Configuração Netlify
├── package.json          # Dependencies
└── README.md
```

---

## 🎯 Passo 2: Conectar ao Netlify

### 2.1 Conectar Repositório

1. Acesse https://app.netlify.com
2. Clique em "Add new site"
3. Selecione "Import an existing project"
4. Escolha "GitHub"
5. Autorize Netlify no GitHub
6. Selecione o repositório `beyond-avaliacao`
7. Clique em "Deploy site"

### 2.2 Configurar Build

Netlify vai detectar `netlify.toml` automaticamente. Verifique:

- **Build command:** `pnpm install && pnpm build`
- **Publish directory:** `client/dist`
- **Functions directory:** `netlify/functions`

---

## 🎯 Passo 3: Configurar Variáveis de Ambiente

### 3.1 Adicionar Variáveis no Netlify

1. Vá para **Site settings** → **Build & deploy** → **Environment**
2. Clique em **Edit variables**
3. Adicione cada variável:

```env
# Banco de Dados (OBRIGATÓRIO)
DATABASE_URL=mysql://user:password@host:3306/beyond_avaliacao

# Stripe (OBRIGATÓRIO para pagamentos)
STRIPE_SECRET_KEY=sk_test_...
STRIPE_PUBLISHABLE_KEY=pk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...

# Google Drive (OBRIGATÓRIO para backup)
GOOGLE_CLIENT_ID=...
GOOGLE_CLIENT_SECRET=...

# JWT (OBRIGATÓRIO para autenticação)
JWT_SECRET=gere_uma_chave_aleatoria_forte_aqui

# Node
NODE_ENV=production
PORT=3000

# Vercel (opcional)
VERCEL_URL=seu-site.netlify.app
```

### 3.2 Obter Credenciais

#### Database URL (Railway)
```bash
# 1. Acesse https://railway.app
# 2. Vá para seu projeto MySQL
# 3. Clique em "Connect"
# 4. Copie a URL em "Database URL"
# Formato: mysql://user:password@host:port/database
```

#### Stripe Keys
```bash
# 1. Acesse https://dashboard.stripe.com/apikeys
# 2. Copie "Secret key" (sk_test_...)
# 3. Copie "Publishable key" (pk_test_...)
# 4. Vá para "Webhooks"
# 5. Crie webhook para: payment_intent.succeeded
# 6. Copie "Signing secret" (whsec_...)
```

#### Google Drive
```bash
# 1. Acesse https://console.cloud.google.com
# 2. Crie novo projeto
# 3. Ative "Google Drive API"
# 4. Crie "OAuth 2.0 Client ID"
# 5. Copie Client ID e Client Secret
```

#### JWT Secret
```bash
# Gere uma chave aleatória forte
openssl rand -base64 32
# Ou use: https://www.uuidgenerator.net/
```

---

## 🎯 Passo 4: Configurar Banco de Dados

### 4.1 Importar Schema

```bash
# 1. Conecte ao banco de dados
mysql -h HOST -u USER -p PASSWORD -D DATABASE

# 2. Cole o conteúdo de database_schema.sql
# Ou execute via terminal:
mysql -h HOST -u USER -p PASSWORD -D DATABASE < database_schema.sql
```

### 4.2 Verificar Conexão

```bash
# Teste a conexão localmente
mysql -h HOST -u USER -p PASSWORD -D DATABASE -e "SHOW TABLES;"
```

---

## 🎯 Passo 5: Configurar Stripe Webhooks

### 5.1 Criar Webhook

1. Acesse https://dashboard.stripe.com/webhooks
2. Clique em "Add endpoint"
3. URL do endpoint: `https://seu-site.netlify.app/api/stripe/webhook`
4. Selecione eventos:
   - `payment_intent.succeeded`
   - `customer.subscription.created`
   - `customer.subscription.updated`
   - `customer.subscription.deleted`
5. Clique em "Add endpoint"
6. Copie "Signing secret" (whsec_...)
7. Adicione em variáveis de ambiente como `STRIPE_WEBHOOK_SECRET`

---

## 🎯 Passo 6: Deploy

### 6.1 Deploy Automático

```bash
# Fazer commit e push
git add .
git commit -m "Deploy configuration"
git push origin main

# Netlify vai fazer deploy automaticamente!
```

### 6.2 Verificar Deploy

1. Vá para https://app.netlify.com
2. Selecione seu site
3. Vá para "Deploys"
4. Aguarde o build terminar (5-10 minutos)
5. Clique em "Preview" quando estiver pronto

---

## 🎯 Passo 7: Configurar Domínio

### 7.1 Domínio Netlify (Gratuito)

```
Seu site está em: https://seu-site.netlify.app
```

### 7.2 Domínio Personalizado

1. Vá para **Site settings** → **Domain management**
2. Clique em "Add custom domain"
3. Digite seu domínio (ex: beyondavaliacao.com.br)
4. Siga as instruções para apontar DNS
5. Espere propagação (até 48 horas)

---

## ✅ Checklist de Deploy

- [ ] Repositório criado no GitHub
- [ ] Conectado ao Netlify
- [ ] Variáveis de ambiente configuradas
- [ ] Banco de dados criado e schema importado
- [ ] Stripe configurado com webhook
- [ ] Google Drive credenciais adicionadas
- [ ] Build bem-sucedido
- [ ] Site acessível
- [ ] Teste de login funcionando
- [ ] Teste de criação de ficha funcionando
- [ ] Teste de pagamento funcionando
- [ ] Domínio personalizado configurado (opcional)

---

## 🧪 Testes Pós-Deploy

### 1. Testar Landing Page
```
https://seu-site.netlify.app/
```

### 2. Testar Registro
```
1. Clique em "Registrar"
2. Preencha email, senha, nome
3. Clique em "Criar Conta"
4. Verifique se foi criado
```

### 3. Testar Login
```
1. Clique em "Entrar"
2. Use email e senha criados
3. Verifique se faz login
```

### 4. Testar Criação de Ficha
```
1. Clique em "Nova Ficha"
2. Preencha dados do paciente
3. Navegue pelas seções
4. Salve a ficha
5. Verifique se aparece no dashboard
```

### 5. Testar Pagamento
```
1. Crie 3 fichas (limite free)
2. Tente criar 4ª ficha
3. Clique em "Upgrade para Premium"
4. Use cartão de teste: 4242 4242 4242 4242
5. Verifique se upgrade funcionou
```

### 6. Testar Google Drive
```
1. Faça login com conta premium
2. Crie uma ficha
3. Verifique se foi salva no Google Drive
```

---

## 🔍 Troubleshooting

### Erro: "Build failed"
```
1. Verifique logs em Netlify
2. Verifique se todas as dependências estão em package.json
3. Verifique se NODE_ENV está correto
4. Tente fazer rebuild
```

### Erro: "Database connection refused"
```
1. Verifique DATABASE_URL está correto
2. Verifique se banco está online
3. Verifique firewall/security groups
4. Teste conexão localmente
```

### Erro: "Stripe webhook failed"
```
1. Verifique STRIPE_WEBHOOK_SECRET está correto
2. Verifique URL do webhook
3. Verifique logs do Stripe Dashboard
4. Recrie webhook se necessário
```

### Erro: "Google Drive not working"
```
1. Verifique GOOGLE_CLIENT_ID e GOOGLE_CLIENT_SECRET
2. Verifique se Google Drive API está ativada
3. Verifique permissões do OAuth
4. Teste localmente primeiro
```

---

## 📊 Monitoramento

### Logs do Netlify
```
1. Vá para "Deploys"
2. Clique em um deploy
3. Vá para "Deploy log"
4. Verifique erros
```

### Logs de Função
```
1. Vá para "Functions"
2. Clique em uma função
3. Vá para "Invocations"
4. Verifique logs
```

### Analytics
```
1. Vá para "Analytics"
2. Veja métricas de uso
3. Monitore performance
```

---

## 🔐 Segurança

### Checklist de Segurança

- [ ] HTTPS ativado (automático no Netlify)
- [ ] Variáveis de ambiente não commitadas
- [ ] JWT_SECRET é forte e aleatório
- [ ] Stripe keys são secretas (não públicas)
- [ ] Google Drive credentials protegidas
- [ ] Database URL não está em código
- [ ] Backups configurados
- [ ] Monitoramento de erros ativado

---

## 💰 Custos

| Serviço | Plano | Preço |
|---------|-------|-------|
| Netlify | Free | R$ 0/mês |
| Railway (DB) | Starter | R$ 5-20/mês |
| Stripe | Pay-as-you-go | 2.9% + R$ 0.30 por transação |
| Google Drive | Free | R$ 0/mês |
| Domínio | .com.br | R$ 30-50/ano |
| **TOTAL** | | **R$ 5-20/mês** |

---

## 📞 Suporte

### Documentação
- Netlify: https://docs.netlify.com
- Stripe: https://stripe.com/docs
- Google Drive: https://developers.google.com/drive

### Comunidades
- Netlify Community: https://community.netlify.com
- Stripe Community: https://stripe.com/community
- Stack Overflow: https://stackoverflow.com

---

## 🎉 Próximos Passos

1. ✅ Deploy no Netlify
2. ✅ Configurar domínio personalizado
3. ✅ Adicionar SSL (automático)
4. ✅ Configurar email de suporte
5. ✅ Adicionar analytics
6. ✅ Configurar backups
7. ✅ Lançar para público!

---

**Seu Beyond Avaliação está pronto para o mundo! 🚀**

Qualquer dúvida, consulte a documentação ou entre em contato com suporte.

---

**Última atualização: Fevereiro 2026**
