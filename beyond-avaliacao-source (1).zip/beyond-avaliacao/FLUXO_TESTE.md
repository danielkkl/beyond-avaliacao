# 🧪 Fluxo de Teste Completo — Beyond Avaliação

## 📋 Resumo do Fluxo

Este documento descreve o fluxo completo de um usuário: **Registro → Criar Ficha → Atingir Limite → Upgrade → Comprar Premium**

---

## 🚀 Passo 1: Acessar a Landing Page

**URL:** `https://3000-is2nxcp3r964r6rvqq6lu-297f726d.us2.manus.computer/`

- Veja a página inicial com hero, features e pricing
- Clique em **"Começar Agora"** ou **"Registrar"**

---

## 📝 Passo 2: Registrar Nova Conta

**URL:** `https://3000-is2nxcp3r964r6rvqq6lu-297f726d.us2.manus.computer/register`

**Dados de Teste:**
```
Email: teste@example.com
Senha: Senha123456
Nome: João Silva
```

**O que acontece:**
- ✅ Conta criada com sucesso
- ✅ Plano **Free** atribuído automaticamente (3 fichas/mês)
- ✅ Redirecionado para dashboard

---

## 🔐 Passo 3: Fazer Login

**URL:** `https://3000-is2nxcp3r964r6rvqq6lu-297f726d.us2.manus.computer/login`

**Dados:**
```
Email: teste@example.com
Senha: Senha123456
```

**O que acontece:**
- ✅ Login bem-sucedido
- ✅ Redirecionado para dashboard
- ✅ Vê contador de fichas: "0/3 fichas usadas"

---

## 📋 Passo 4: Criar Primeira Ficha

**URL:** `https://3000-is2nxcp3r964r6rvqq6lu-297f726d.us2.manus.computer/ficha`

**O que fazer:**
1. Preencha os dados do paciente (nome, data de nascimento, etc)
2. Preencha algumas seções (anamnese, sinais vitais)
3. Clique em **"Salvar Ficha"**

**O que acontece:**
- ✅ Ficha salva com sucesso
- ✅ Contador atualiza: "1/3 fichas usadas"
- ✅ PDF gerado automaticamente
- ✅ Redirecionado para dashboard

---

## 📋 Passo 5: Criar Segunda e Terceira Ficha

**Repita o Passo 4** mais 2 vezes com dados diferentes

**Resultado:**
- Contador: "3/3 fichas usadas"
- Botão "Nova Ficha" desabilitado com mensagem: **"Limite de 3 fichas/mês atingido"**

---

## 🚨 Passo 6: Tentar Criar Quarta Ficha (Erro)

**URL:** `https://3000-is2nxcp3r964r6rvqq6lu-297f726d.us2.manus.computer/ficha`

**O que acontece:**
- ❌ Mensagem de erro: **"Limite de 3 fichas/mês atingido no plano Free. Upgrade para Premium!"**
- ✅ Botão **"Upgrade para Premium"** aparece

---

## 💳 Passo 7: Fazer Upgrade para Premium

**URL:** `https://3000-is2nxcp3r964r6rvqq6lu-297f726d.us2.manus.computer/upgrade`

**O que ver:**
- ✅ Página de pricing com 2 planos:
  - **Monthly:** R$ 49.90/mês
  - **Yearly:** R$ 499.00/ano (2 meses grátis)
- ✅ Tabela de comparação Free vs Premium
- ✅ FAQ com 4 perguntas

**O que fazer:**
1. Selecione **"Monthly"** (ou "Yearly")
2. Clique em **"Assinar Agora"**

---

## 💰 Passo 8: Checkout Stripe (Teste)

**URL:** Redirecionado para Stripe Checkout

**Dados de Teste (Stripe):**
```
Cartão: 4242 4242 4242 4242
Validade: 12/26
CVC: 123
Nome: João Silva
```

**O que acontece:**
- ✅ Pagamento processado (teste)
- ✅ Redirecionado para `/dashboard?payment=success`
- ✅ Plano atualizado para **Premium**
- ✅ Contador desaparece (fichas ilimitadas)

---

## 🎉 Passo 9: Usar Premium

**URL:** `https://3000-is2nxcp3r964r6rvqq6lu-297f726d.us2.manus.computer/dashboard`

**O que fazer:**
1. Crie uma **4ª ficha** (agora funciona!)
2. Acesse `/reports` para ver **relatórios avançados**
3. Acesse `/dashboard-novo` para ver **novo dashboard**
4. Acesse `/paciente/1` para ver **perfil do paciente**

**O que acontece:**
- ✅ Todas as funcionalidades premium desbloqueadas
- ✅ Google Drive automático (se configurado)
- ✅ Relatórios com gráficos
- ✅ Análise de evolução

---

## 📊 Passo 10: Testar Funcionalidades Premium

### Relatórios (`/reports`)
- Gráficos de evolução de dor (EVA)
- Gráficos de força muscular
- Gráficos de ADM
- Exportar em PDF/CSV

### Dashboard Novo (`/dashboard-novo`)
- 4 cards de estatísticas
- Tabela de fichas recentes
- Grid de pacientes com busca e filtros
- Barra de progresso visual

### Perfil do Paciente (`/paciente/1`)
- Informações pessoais e clínicas
- Histórico completo de fichas
- Tabela de evolução de medições
- Botões de ação (Ver, Editar, Deletar)

---

## 🧪 Dados de Teste Adicionais

### Cartões Stripe (Teste)
| Cartão | Resultado |
|--------|-----------|
| 4242 4242 4242 4242 | ✅ Sucesso |
| 4000 0000 0000 0002 | ❌ Recusado |
| 4000 0000 0000 0069 | ⚠️ Expirado |

### Emails de Teste
```
teste@example.com
usuario@test.com
fisio@clinic.com
```

---

## 🔧 Troubleshooting

### Erro: "Email já registrado"
- Use um email diferente
- Ou delete o usuário do banco de dados

### Erro: "Falha ao gerar PDF"
- Verifique se o servidor está rodando
- Verifique logs em `/tmp/terminal-bg-dev-*.log`

### Erro: "Falha ao criar sessão Stripe"
- Verifique se `STRIPE_SECRET_KEY` está configurado
- Verifique se os IDs de preço estão corretos

### Pagamento não processado
- Use o cartão de teste: 4242 4242 4242 4242
- Verifique o webhook em Stripe Dashboard

---

## 📈 Métricas para Validar

Após completar o fluxo, você deve ter:

- ✅ 1 usuário registrado
- ✅ 4+ fichas criadas
- ✅ 1 assinatura Premium ativa
- ✅ Acesso a relatórios e dashboard premium
- ✅ Limite de fichas desbloqueado

---

## 🎯 Próximos Passos

1. **Testar em Produção:** Deploy na Vercel/Railway
2. **Configurar Domínio:** Comprar domínio customizado
3. **Ativar Stripe Live:** Mudar para chaves de produção
4. **Marketing:** Criar landing page otimizada para SEO
5. **Suporte:** Implementar chat de suporte

---

## 📞 Contato

Se encontrar problemas, verifique:
- Logs do servidor: `tail -f /tmp/terminal-bg-dev-*.log`
- Console do navegador: F12 → Console
- Stripe Dashboard: https://dashboard.stripe.com

**Bom teste! 🚀**
