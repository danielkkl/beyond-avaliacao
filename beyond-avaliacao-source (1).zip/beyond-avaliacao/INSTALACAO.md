# Beyond Avaliação — Guia de Instalação e Uso

## 📋 Visão Geral

**Beyond Avaliação** é um sistema SaaS completo para fisioterapeutas gerenciarem fichas de avaliação, com:

- ✅ Autenticação email/senha
- ✅ Sistema freemium (Free: 3 fichas/mês, Premium: ilimitado)
- ✅ Integração Stripe para pagamento
- ✅ Google Drive automático (Premium)
- ✅ Relatórios com gráficos
- ✅ Dashboard profissional
- ✅ Geração de PDF

---

## 🚀 Instalação Rápida

### 1. Pré-requisitos

- Node.js 18+ instalado
- npm ou pnpm
- MySQL 8.0+ (ou TiDB)
- Conta Stripe (opcional, para testes)
- Conta Google Cloud (opcional, para Google Drive)

### 2. Clonar/Descompactar o Projeto

```bash
# Se recebeu como tar.gz
tar -xzf beyond-avaliacao-completo.tar.gz
cd beyond-avaliacao

# Ou clone do repositório
git clone <seu-repositorio>
cd beyond-avaliacao
```

### 3. Instalar Dependências

```bash
pnpm install
# ou
npm install
```

### 4. Configurar Variáveis de Ambiente

Crie um arquivo `.env` na raiz do projeto:

```env
# Banco de Dados
DATABASE_URL="mysql://usuario:senha@localhost:3306/beyond_avaliacao"

# JWT
JWT_SECRET="sua-chave-secreta-super-segura-aqui"

# Stripe (opcional)
STRIPE_SECRET_KEY="sk_test_..."
STRIPE_WEBHOOK_SECRET="whsec_test_..."
VITE_STRIPE_PUBLISHABLE_KEY="pk_test_..."

# Google OAuth (opcional)
GOOGLE_OAUTH_CLIENT_ID="seu-client-id.apps.googleusercontent.com"
GOOGLE_OAUTH_CLIENT_SECRET="sua-client-secret"

# URLs
VITE_API_URL="http://localhost:3000"
VITE_APP_TITLE="Beyond Avaliação"
```

### 5. Configurar Banco de Dados

```bash
# Criar banco de dados
mysql -u root -p -e "CREATE DATABASE beyond_avaliacao;"

# Executar migrações
pnpm db:push
```

### 6. Iniciar o Servidor

```bash
# Desenvolvimento
pnpm dev

# Produção
pnpm build
pnpm start
```

O servidor estará disponível em: **http://localhost:3000**

---

## 📁 Estrutura do Projeto

```
beyond-avaliacao/
├── client/                 # Frontend React + Vite
│   ├── src/
│   │   ├── pages/         # Páginas principais
│   │   │   ├── Home.tsx   # Landing page
│   │   │   ├── Login.tsx  # Login
│   │   │   ├── Register.tsx
│   │   │   ├── Dashboard.tsx
│   │   │   ├── Ficha.tsx  # Criação de ficha
│   │   │   ├── Reports.tsx # Relatórios
│   │   │   └── ...
│   │   ├── components/    # Componentes reutilizáveis
│   │   ├── hooks/         # Custom hooks
│   │   ├── App.tsx        # Rotas principais
│   │   └── index.css      # Estilos globais
│   └── public/            # Assets estáticos
├── server/                # Backend Express + tRPC
│   ├── routers.ts         # Procedimentos tRPC
│   ├── auth.service.ts    # Serviço de autenticação
│   ├── stripe-router.ts   # Integração Stripe
│   ├── storage.ts         # Integração S3
│   └── _core/             # Configuração interna
├── drizzle/               # Migrações do banco
│   ├── schema.ts          # Definição de tabelas
│   └── migrations/        # Histórico de migrações
├── shared/                # Código compartilhado
├── package.json
└── README.md
```

---

## 🔐 Autenticação

### Registrar Usuário

```bash
curl -X POST http://localhost:3000/api/trpc/auth.register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "usuario@example.com",
    "password": "Senha123456",
    "name": "João Silva"
  }'
```

### Fazer Login

```bash
curl -X POST http://localhost:3000/api/trpc/auth.login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "usuario@example.com",
    "password": "Senha123456"
  }'
```

---

## 💳 Integração Stripe

### 1. Obter Chaves Stripe

1. Acesse https://dashboard.stripe.com
2. Vá para **Developers → API Keys**
3. Copie `Secret Key` e `Publishable Key`
4. Adicione ao `.env`

### 2. Testar Pagamento

Use o cartão de teste:
- **Número**: 4242 4242 4242 4242
- **Validade**: 12/26
- **CVC**: 123

### 3. Webhook (Produção)

Configure o webhook em **Developers → Webhooks**:
- URL: `https://seu-dominio.com/api/stripe/webhook`
- Eventos: `checkout.session.completed`, `invoice.paid`

---

## 🔗 Google Drive (Premium)

### 1. Criar Credenciais Google

1. Acesse https://console.cloud.google.com
2. Crie um novo projeto
3. Ative a API do Google Drive
4. Crie credenciais OAuth 2.0
5. Adicione ao `.env`

### 2. Autorizar Usuário

O usuário será solicitado a autorizar na primeira vez que usar a funcionalidade.

---

## 📊 Banco de Dados

### Tabelas Principais

```sql
-- Usuários
CREATE TABLE users (
  id INT PRIMARY KEY AUTO_INCREMENT,
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  name VARCHAR(255),
  plan ENUM('free', 'premium') DEFAULT 'free',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Fichas de Avaliação
CREATE TABLE fichas (
  id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT NOT NULL,
  paciente_nome VARCHAR(255),
  data_avaliacao DATE,
  eva INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Planos/Assinaturas
CREATE TABLE user_plans (
  id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT NOT NULL UNIQUE,
  plan VARCHAR(50) DEFAULT 'free',
  stripe_subscription_id VARCHAR(255),
  fichas_mes INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);
```

---

## 🧪 Testes

### Executar Testes

```bash
pnpm test
```

### Testes de Integração

```bash
# Testar autenticação
pnpm test auth

# Testar fichas
pnpm test fichas

# Testar Stripe
pnpm test stripe
```

---

## 📈 Deployment

### Heroku

```bash
# Login
heroku login

# Criar app
heroku create beyond-avaliacao

# Configurar variáveis
heroku config:set DATABASE_URL="mysql://..."
heroku config:set JWT_SECRET="..."

# Deploy
git push heroku main
```

### Docker

```bash
# Build
docker build -t beyond-avaliacao .

# Run
docker run -p 3000:3000 \
  -e DATABASE_URL="mysql://..." \
  -e JWT_SECRET="..." \
  beyond-avaliacao
```

### Vercel (Frontend)

```bash
# Deploy
vercel deploy
```

---

## 🐛 Troubleshooting

### Erro: "Cannot find module"

```bash
pnpm install
pnpm db:push
```

### Erro: "Database connection failed"

Verifique:
- MySQL está rodando
- `DATABASE_URL` está correto
- Banco de dados foi criado

### Erro: "JWT_SECRET not found"

Adicione ao `.env`:
```env
JWT_SECRET="sua-chave-secreta"
```

### Erro: "Stripe key not found"

Adicione ao `.env`:
```env
STRIPE_SECRET_KEY="sk_test_..."
VITE_STRIPE_PUBLISHABLE_KEY="pk_test_..."
```

---

## 📚 Documentação Adicional

- [Documentação React](https://react.dev)
- [Documentação Express](https://expressjs.com)
- [Documentação tRPC](https://trpc.io)
- [Documentação Stripe](https://stripe.com/docs)
- [Documentação Google Drive API](https://developers.google.com/drive)

---

## 📞 Suporte

Para dúvidas ou problemas:

1. Verifique a seção Troubleshooting
2. Consulte a documentação oficial
3. Abra uma issue no repositório
4. Entre em contato: contato@beyondavaliacao.com.br

---

## 📄 Licença

Este projeto é propriedade de Beyond Avaliação. Todos os direitos reservados.

---

## 🎉 Pronto!

Seu sistema Beyond Avaliação está pronto para usar. Comece a criar fichas de avaliação profissionais!

**Acesse**: http://localhost:3000
