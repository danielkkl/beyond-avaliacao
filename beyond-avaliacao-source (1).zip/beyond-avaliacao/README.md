# Beyond Avaliação

**Ficha de Avaliação Fisioterapêutica Profissional e Científica**

Uma plataforma web moderna, segura e baseada em evidências para criação, gerenciamento e geração de fichas de avaliação fisioterapêutica. Desenvolvida para fisioterapeutas que buscam excelência clínica e eficiência operacional.

---

## 🎯 Visão Geral

Beyond Avaliação é um sistema integrado que combina:

- **Rigor Científico**: Baseado em protocolos internacionais (CIF, EVA, IMC, Classificação de Força Muscular)
- **Design Profissional**: Interface intuitiva seguindo padrões de saúde (Medical Precision Design)
- **Segurança**: Autenticação segura, criptografia de dados, conformidade LGPD
- **Escalabilidade**: Modelo freemium com integração Stripe para pagamento
- **Integração em Nuvem**: Google Drive para armazenamento seguro de PDFs

---

## 📋 Seções da Ficha

### 1. **Identificação Completa do Paciente**
Coleta dados demográficos, clínicos e de contato essenciais para documentação profissional.

**Campos**: Nome, data de nascimento, sexo, estado civil, CPF, telefone, e-mail, endereço, profissão, diagnóstico clínico, médico solicitante, plano de saúde, número de prontuário, data da avaliação, consultor responsável.

---

### 2. **Hábitos de Vida**
Avaliação dos fatores de risco e estilo de vida que impactam na saúde e recuperação.

**Campos**: Alimentação, sono, ingestão hídrica, rotina diária, atividade física, medicamentos em uso, tabagismo, etilismo, estresse, trabalho repetitivo, histórico esportivo.

---

### 3. **Sinais Vitais e Antropometria**
Medição de parâmetros fisiológicos com **cálculos automáticos** baseados em fórmulas científicas.

**Parâmetros Medidos**:
- PA (Pressão Arterial)
- FC (Frequência Cardíaca)
- FR (Frequência Respiratória)
- SatO₂ (Saturação de Oxigênio)
- Temperatura
- Glicemia
- Peso e Altura

**Cálculos Automáticos**:
- **IMC (Índice de Massa Corporal)**: `IMC = peso (kg) / altura (m)²`
  - Classificação WHO: Baixo peso (<18.5), Peso normal (18.5-24.9), Sobrepeso (25-29.9), Obesidade (≥30)
- **FC Máx**: `FC Máx = 220 - idade` (Fórmula de Karvonen)
- **Zona de Treino 60-80%**: Frequência cardíaca alvo para exercício aeróbico
- **FR Máx Estimada**: Baseada em idade e condição clínica

**Referências Científicas**:
- WHO. (2021). Global Health Observatory Data Repository
- Karvonen, M. J., Kentala, E., & Mustala, O. (1957). The effects of training on heart rate. Annals of Medicine and Experimental Biology and Fenn, 35(3), 307-315.

---

### 4. **Anamnese Completa**
Coleta estruturada da história clínica do paciente.

**Componentes**:
- **HDA** (História da Doença Atual): Apresentação atual dos sintomas
- **HDP** (História da Doença Pregressa): Antecedentes médicos relevantes
- **EVA** (Escala Visual Analógica): Avaliação da intensidade da dor (0-10)
- Características da dor (tipo, irradiação, fatores de melhora/piora)
- Cirurgias anteriores

**Referência Científica**:
- Huskisson, E. C. (1974). Measurement of pain. Lancet, 2(7889), 1127-1131.

---

### 5. **Exame Físico**
Avaliação clínica estruturada do paciente.

**Componentes**:
- Inspeção visual
- Palpação
- Avaliação postural (estática e dinâmica)
- Análise da marcha
- Perimetria (medidas segmentares)
- Testes especiais (ortopédicos e neurológicos)

---

### 6. **Mapa da Dor**
Localização visual e quantificação da dor corporal com mapa anatômico profissional.

**Funcionalidades**:
- Silhueta humana com 45 regiões numeradas (frente e costas)
- 5 níveis de intensidade de dor (cores: verde → vermelho)
- Pincel ajustável para precisão
- Botão limpar para reiniciar

---

### 7. **ADM / Força Muscular — Classificação CIF**
Avaliação de amplitude de movimento (ADM) e força muscular com classificação automática.

**Classificação CIF (Classificação Internacional de Funcionalidade)**:
- **XXX.0**: Sem déficit (0%)
- **XXX.1**: Déficit leve (<4%)
- **XXX.2**: Déficit moderado (4-24%)
- **XXX.3**: Déficit grave (25-49%)
- **XXX.4**: Déficit completo (≥50%)

**Escala de Força Muscular** (0-5):
- 0: Sem contração
- 1: Contração palpável sem movimento
- 2: Movimento com eliminação da gravidade
- 3: Movimento contra a gravidade
- 4: Movimento contra resistência moderada
- 5: Força normal

**Referência Científica**:
- OMS. (2001). Classificação Internacional de Funcionalidade, Incapacidade e Saúde (CIF).

---

### 8. **Prescrições Terapêuticas**
Planejamento estruturado de exercícios e condutas terapêuticas.

**Campos**: Descrição do exercício, objetivo, frequência, quantidade (séries/repetições), progressão, observações.

---

### 9. **Estratégias Terapêuticas**
Planejamento em três horizontes temporais.

**Prazos**:
- **Curto Prazo** (1-4 semanas): Objetivos imediatos
- **Médio Prazo** (1-3 meses): Consolidação de ganhos
- **Longo Prazo** (3+ meses): Manutenção e prevenção

---

### 10. **Evolução do Tratamento**
Registro dinâmico do progresso clínico ao longo das sessões.

**Registro por Sessão**: Data, fisioterapeuta (CREFITO), descrição da sessão, resposta ao tratamento, ajustes de conduta.

---

### 11. **Termo de Consentimento Informado**
Documentação legal e ética do consentimento do paciente.

**Consentimentos**:
- Autorização para tratamento fisioterapêutico
- Consentimento fotográfico (com restrições de divulgação)
- Política de faltas (24h de antecedência)
- Reposição de sessões

---

### 12. **Assinaturas Digitais**
Canvas interativo para captura de assinaturas do paciente e fisioterapeuta.

---

## 💰 Modelo de Negócio

### Plano Gratuito (Free)
- **Limite**: 3 fichas por mês
- **Recursos**: Acesso básico a todas as seções
- **Armazenamento**: Apenas no navegador (sem sincronização)
- **PDF**: Geração local (sem Google Drive)

### Plano Premium
- **Limite**: Fichas ilimitadas
- **Recursos**: Todas as funcionalidades
- **Google Drive**: Sincronização automática de PDFs
- **Histórico**: Acesso completo a fichas anteriores
- **Relatórios**: Análise de evolução do paciente
- **Suporte**: Prioridade técnica
- **Preço**: R$ 49,90/mês ou R$ 499/ano

---

## 🔐 Segurança e Conformidade

- **Autenticação**: Email/senha com JWT seguro
- **Criptografia**: Dados sensíveis criptografados em repouso
- **LGPD**: Conformidade com Lei Geral de Proteção de Dados
- **HTTPS**: Comunicação segura end-to-end
- **Backup**: Sincronização automática com Google Drive (premium)

---

## 🛠️ Stack Tecnológico

### Frontend
- **React 19**: UI moderna e reativa
- **TypeScript**: Type safety
- **Tailwind CSS 4**: Design responsivo
- **Shadcn/UI**: Componentes acessíveis

### Backend
- **Express.js**: API RESTful
- **tRPC**: Type-safe RPC
- **MySQL/TiDB**: Banco de dados relacional
- **Drizzle ORM**: Queries type-safe

### Integrações
- **Stripe**: Processamento de pagamentos
- **Google Drive API**: Armazenamento em nuvem
- **JWT**: Autenticação segura

---

## 📊 Referências Científicas

1. **WHO (2001)**: Classificação Internacional de Funcionalidade, Incapacidade e Saúde (CIF)
   - Padrão internacional para avaliação funcional

2. **Huskisson, E. C. (1974)**: Measurement of pain. Lancet
   - Validação da Escala Visual Analógica (EVA)

3. **Karvonen, M. J. et al. (1957)**: The effects of training on heart rate
   - Fórmula de cálculo de FC Máx e zona de treino

4. **WHO (2021)**: Global Health Observatory Data Repository
   - Classificação de IMC e critérios de saúde

5. **Kendall, F. P., McCreary, E. K., & Provance, P. G. (2005)**: Músculos: Testes e Funções
   - Escala de força muscular (0-5)

---

## 🚀 Como Começar

### Instalação

```bash
# Clonar repositório
git clone https://github.com/seu-usuario/beyond-avaliacao.git
cd beyond-avaliacao

# Instalar dependências
pnpm install

# Configurar banco de dados
pnpm db:push

# Iniciar servidor de desenvolvimento
pnpm dev
```

### Variáveis de Ambiente

```env
# Banco de dados
DATABASE_URL=mysql://user:password@localhost:3306/beyond_avaliacao

# Autenticação
JWT_SECRET=sua-chave-secreta-aqui

# Stripe
STRIPE_SECRET_KEY=sk_test_...
STRIPE_PUBLISHABLE_KEY=pk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...

# Google Drive
GOOGLE_OAUTH_CLIENT_ID=seu-client-id.apps.googleusercontent.com
GOOGLE_OAUTH_CLIENT_SECRET=sua-client-secret
```

---

## 📱 Responsividade

- ✅ Desktop (1920px+)
- ✅ Tablet (768px - 1024px)
- ✅ Mobile (320px - 767px)
- ✅ Otimizado para impressão (PDF)

---

## 🎨 Design System

**Cores Funcionais**:
- **Primária**: Emerald (#059669) — Ações positivas, confirmações
- **Secundária**: Slate (#334155) — Texto, bordas, neutro
- **Alerta**: Amber (#D97706) — Valores fora do padrão
- **Sucesso**: Green (#16A34A) — Confirmações
- **Erro**: Red (#EF4444) — Avisos críticos

**Tipografia**:
- **Títulos**: DM Sans 700
- **Corpo**: Inter 400/500
- **Números**: JetBrains Mono (precisão)

---

## 📈 Roadmap

- [ ] Integração com prontuário eletrônico (PEP)
- [ ] Relatórios automáticos em PDF
- [ ] Análise de evolução com gráficos
- [ ] App mobile (React Native)
- [ ] Integração com wearables (Apple Watch, Fitbit)
- [ ] Telemedicina (videochamada integrada)
- [ ] IA para sugestões de conduta

---

## 📞 Suporte

- **Email**: suporte@beyondavaliacao.com.br
- **Documentação**: https://docs.beyondavaliacao.com.br
- **Status**: https://status.beyondavaliacao.com.br

---

## 📄 Licença

MIT License — Veja LICENSE.md para detalhes

---

## 👥 Autores

Desenvolvido por fisioterapeutas e engenheiros de software para a excelência clínica.

---

**Beyond Avaliação** — Transformando a avaliação fisioterapêutica em ciência e tecnologia.
