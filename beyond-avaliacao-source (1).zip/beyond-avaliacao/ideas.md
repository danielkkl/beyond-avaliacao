# AvaliaFisio – Ideias de Design

## Contexto
Aplicativo de ficha de avaliação fisioterapêutica. Público: fisioterapeutas clínicos.
Precisa ser funcional, claro, confiável e com aparência profissional de saúde.

---

<response>
<probability>0.07</probability>
<idea>

**Design Movement:** Medical Precision — Bauhaus aplicado à saúde

**Core Principles:**
1. Hierarquia tipográfica rigorosa: cada seção tem peso e tamanho distintos
2. Grid assimétrico: sidebar de navegação fixa à esquerda, conteúdo principal à direita
3. Cores funcionais: cada seção da ficha tem uma cor-âncora distinta para orientação rápida
4. Densidade informacional controlada: formulários compactos mas respiráveis

**Color Philosophy:**
- Fundo: branco clínico (#FAFAFA)
- Sidebar: verde-azulado profundo (#0D4F4F) — transmite saúde, seriedade
- Accent primário: verde-esmeralda (#059669) — ações positivas, confirmações
- Accent secundário: azul-ardósia (#334155) — seções neutras
- Destaque de alerta: âmbar (#D97706) — valores fora do padrão
- Texto: carvão (#1E293B)

**Layout Paradigm:**
- Sidebar fixa à esquerda com navegação por seções (âncoras)
- Conteúdo principal com scroll contínuo
- Header fixo com nome do paciente e botão de PDF
- Progress indicator mostrando % de preenchimento

**Signature Elements:**
1. Badges coloridos por seção (Identificação, Sinais Vitais, etc.)
2. Cards com borda-esquerda colorida indicando categoria
3. Indicadores visuais de cálculo automático (IMC, FC) com badges de classificação

**Interaction Philosophy:**
- Cálculos automáticos com feedback visual imediato (badge colorido de classificação)
- Campos readonly com fundo levemente diferenciado
- Hover suave nos campos de input
- Botão de adicionar linha com animação de entrada

**Animation:**
- Entradas de seção com fade-in + slide-up (100ms delay escalonado)
- Campos calculados pulsam brevemente ao atualizar
- Sidebar item ativo com transição de cor suave

**Typography System:**
- Display/Títulos: DM Sans 700 — moderno, médico, sem serifa geométrica
- Corpo/Labels: Inter 400/500 — legibilidade máxima
- Valores calculados: JetBrains Mono — transmite precisão numérica

</idea>
</response>

<response>
<probability>0.05</probability>
<idea>

**Design Movement:** Clinical Minimalism — Escandinavo aplicado à medicina

**Core Principles:**
1. Espaço em branco como elemento principal
2. Tipografia como único ornamento
3. Formulário como documento — aparência de prontuário digital
4. Interação quase invisível

**Color Philosophy:**
- Fundo: cinza muito claro (#F8FAFC)
- Seções: branco puro com sombra sutil
- Accent único: azul-marinho (#1E40AF)
- Texto: quase-preto (#0F172A)
- Bordas: cinza muito suave (#E2E8F0)

**Layout Paradigm:**
- Uma coluna central larga (max 800px)
- Seções como "cards de documento" empilhados
- Sem sidebar — navegação por scroll com indicador flutuante

**Signature Elements:**
1. Linha horizontal colorida no topo de cada seção
2. Labels acima dos campos (não placeholder)
3. Numeração de seção em cinza claro à esquerda

**Interaction Philosophy:**
- Campos com borda que acende em azul ao focar
- Validação silenciosa
- PDF gerado com aparência idêntica ao formulário

**Animation:**
- Sem animações excessivas — apenas transições de foco (150ms)
- Scroll suave entre seções

**Typography System:**
- Títulos: Sora 600
- Corpo: Source Sans 3 400
- Números: Roboto Mono

</idea>
</response>

<response>
<probability>0.08</probability>
<idea>

**Design Movement:** Healthcare Dashboard — Material Design 3 para saúde

**Core Principles:**
1. Abas por categoria de avaliação
2. Cards elevados com sombra para cada grupo de campos
3. Indicadores visuais de progresso e status
4. Responsividade total (mobile-first)

**Color Philosophy:**
- Fundo: azul-acinzentado muito claro (#EFF6FF)
- Cards: branco com sombra suave
- Primary: azul-médico (#2563EB)
- Success: verde (#16A34A)
- Warning: laranja (#EA580C)
- Seções: cada uma com cor própria no cabeçalho

**Layout Paradigm:**
- Tabs horizontais no topo para cada seção
- Cada tab mostra um "card de formulário"
- Botão flutuante de salvar/imprimir
- Barra de progresso global

**Signature Elements:**
1. Chips/badges de status nos campos calculados
2. Ícones médicos em cada seção
3. Mini-resumo no topo (nome, idade, IMC) sempre visível

**Interaction Philosophy:**
- Navegação por tabs com animação de slide
- Campos com validação em tempo real
- Toast notifications para ações

**Animation:**
- Transição de tab com slide horizontal
- Campos inválidos com shake suave
- Valores calculados com counter animation

**Typography System:**
- Títulos: Plus Jakarta Sans 700
- Corpo: Nunito 400/600
- Números: Space Mono

</idea>
</response>

---

## Escolha Final

**Abordagem escolhida: Medical Precision (Resposta 1)**

Sidebar fixa com navegação por seções, cores funcionais por categoria, tipografia DM Sans + Inter + JetBrains Mono, cards com borda-esquerda colorida, cálculos automáticos com badges visuais de classificação.
