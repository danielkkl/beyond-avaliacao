import { jsPDF } from "jspdf";
import { storagePut } from "./storage";
import { Buffer } from "buffer";

interface FichaData {
  nomePaciente: string;
  dataNascimento?: string;
  idadeAtual?: number;
  sexo?: string;
  peso?: number;
  altura?: number;
  imc?: number;
  classificacaoIMC?: string;
  pa?: string;
  fc?: string;
  eva?: number;
  diagnosticoClinico?: string;
  hda?: string;
  prescricoes?: any[];
  evolucoes?: any[];
  dataAvaliacao?: string;
  consultor?: string;
}

export async function generateAndUploadFichaPDF(
  userId: number,
  fichaId: number,
  fichaData: FichaData
): Promise<{ url: string; key: string }> {
  try {
    // Create PDF
    const pdf = new jsPDF();
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    let yPosition = 20;

    // Header
    pdf.setFillColor(16, 185, 129); // Emerald green
    pdf.rect(0, 0, pageWidth, 30, "F");

    pdf.setTextColor(255, 255, 255);
    pdf.setFontSize(20);
    pdf.text("AvaliaFisio", 20, 20);

    pdf.setTextColor(0, 0, 0);
    pdf.setFontSize(12);
    yPosition = 45;

    // Patient Info
    pdf.setFontSize(14);
    pdf.text("Identificação do Paciente", 20, yPosition);
    yPosition += 10;

    pdf.setFontSize(11);
    pdf.text(`Nome: ${fichaData.nomePaciente || "---"}`, 20, yPosition);
    yPosition += 7;
    pdf.text(`Data de Nascimento: ${fichaData.dataNascimento || "---"}`, 20, yPosition);
    yPosition += 7;
    pdf.text(`Idade: ${fichaData.idadeAtual || "---"} anos`, 20, yPosition);
    yPosition += 7;
    pdf.text(`Sexo: ${fichaData.sexo || "---"}`, 20, yPosition);
    yPosition += 7;
    pdf.text(`Diagnóstico: ${fichaData.diagnosticoClinico || "---"}`, 20, yPosition);
    yPosition += 15;

    // Vital Signs
    pdf.setFontSize(14);
    pdf.text("Sinais Vitais", 20, yPosition);
    yPosition += 10;

    pdf.setFontSize(11);
    pdf.text(`PA: ${fichaData.pa || "---"}`, 20, yPosition);
    yPosition += 7;
    pdf.text(`FC: ${fichaData.fc || "---"} bpm`, 20, yPosition);
    yPosition += 7;
    pdf.text(`Peso: ${fichaData.peso || "---"} kg`, 20, yPosition);
    yPosition += 7;
    pdf.text(`Altura: ${fichaData.altura || "---"} m`, 20, yPosition);
    yPosition += 7;
    pdf.text(`IMC: ${fichaData.imc || "---"} (${fichaData.classificacaoIMC || "---"})`, 20, yPosition);
    yPosition += 7;
    pdf.text(`EVA: ${fichaData.eva || "---"}/10`, 20, yPosition);
    yPosition += 15;

    // Anamnesis
    if (fichaData.hda) {
      pdf.setFontSize(14);
      pdf.text("Anamnese", 20, yPosition);
      yPosition += 10;

      pdf.setFontSize(11);
      const hdaLines = pdf.splitTextToSize(fichaData.hda, pageWidth - 40);
      pdf.text(hdaLines, 20, yPosition);
      yPosition += hdaLines.length * 5 + 10;
    }

    // Prescriptions
    if (fichaData.prescricoes && fichaData.prescricoes.length > 0) {
      if (yPosition > pageHeight - 40) {
        pdf.addPage();
        yPosition = 20;
      }

      pdf.setFontSize(14);
      pdf.text("Prescrições", 20, yPosition);
      yPosition += 10;

      pdf.setFontSize(10);
      fichaData.prescricoes.forEach((presc: any, idx: number) => {
        if (yPosition > pageHeight - 20) {
          pdf.addPage();
          yPosition = 20;
        }

        pdf.text(`${idx + 1}. ${presc.descricao || "---"}`, 20, yPosition);
        yPosition += 5;
        pdf.text(`   Frequência: ${presc.frequencia || "---"}`, 25, yPosition);
        yPosition += 5;
        pdf.text(`   Quantidade: ${presc.quantidade || "---"}`, 25, yPosition);
        yPosition += 5;
        pdf.text(`   Objetivo: ${presc.objetivo || "---"}`, 25, yPosition);
        yPosition += 8;
      });
    }

    // Footer
    pdf.setFontSize(9);
    pdf.setTextColor(128, 128, 128);
    const date = new Date().toLocaleDateString("pt-BR");
    pdf.text(`Gerado em: ${date}`, 20, pageHeight - 10);
    pdf.text(`Fisioterapeuta: ${fichaData.consultor || "---"}`, pageWidth - 100, pageHeight - 10);

    // Convert to buffer and upload
    const pdfBuffer = Buffer.from(pdf.output("arraybuffer"));
    const fileName = `ficha-${fichaData.nomePaciente?.replace(/\s+/g, "-") || "paciente"}-${fichaId}-${Date.now()}.pdf`;
    const fileKey = `fichas/${userId}/${fileName}`;

    const result = await storagePut(fileKey, pdfBuffer, "application/pdf");

    return {
      url: result.url,
      key: result.key,
    };
  } catch (error) {
    console.error("Error generating PDF:", error);
    throw new Error("Failed to generate PDF");
  }
}
