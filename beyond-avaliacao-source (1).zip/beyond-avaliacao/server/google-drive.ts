import { google } from "googleapis";
import { getGoogleDriveToken, saveGoogleDriveToken } from "./db";

const oauth2Client = new google.auth.OAuth2(
  process.env.GOOGLE_OAUTH_CLIENT_ID,
  process.env.GOOGLE_OAUTH_CLIENT_SECRET,
  process.env.GOOGLE_OAUTH_REDIRECT_URL || "http://localhost:3000/api/google/callback"
);

export function getGoogleAuthUrl(): string {
  return oauth2Client.generateAuthUrl({
    access_type: "offline",
    scope: [
      "https://www.googleapis.com/auth/drive.file",
      "https://www.googleapis.com/auth/userinfo.email",
    ],
  });
}

export async function handleGoogleCallback(code: string, userId: number): Promise<void> {
  try {
    const { tokens } = await oauth2Client.getToken(code);
    
    await saveGoogleDriveToken(userId, {
      accessToken: tokens.access_token,
      refreshToken: tokens.refresh_token,
      expiresAt: tokens.expiry_date ? new Date(tokens.expiry_date) : null,
    });

    console.log(`[Google Drive] User ${userId} connected successfully`);
  } catch (error) {
    console.error("[Google Drive] Error handling callback:", error);
    throw new Error("Failed to connect Google Drive");
  }
}

export async function uploadPDFToGoogleDrive(
  userId: number,
  fileName: string,
  fileBuffer: Buffer
): Promise<string> {
  try {
    const token = await getGoogleDriveToken(userId);
    
    if (!token || !token.accessToken) {
      throw new Error("Google Drive not connected for this user");
    }

    oauth2Client.setCredentials({
      access_token: token.accessToken,
      refresh_token: token.refreshToken,
    });

    const drive = google.drive({ version: "v3", auth: oauth2Client });

    const fileMetadata = {
      name: fileName,
      mimeType: "application/pdf",
      parents: ["appDataFolder"], // Save to app data folder
    };

    const media = {
      mimeType: "application/pdf",
      body: fileBuffer,
    };

    const response = await drive.files.create({
      requestBody: fileMetadata as any,
      media: media as any,
      fields: "id, webViewLink",
    });

    console.log(`[Google Drive] File uploaded: ${response.data.id}`);
    return response.data.id || "";
  } catch (error) {
    console.error("[Google Drive] Error uploading file:", error);
    throw new Error("Failed to upload file to Google Drive");
  }
}

export async function disconnectGoogleDrive(userId: number): Promise<void> {
  try {
    // In a real app, you'd revoke the token here
    // For now, just remove it from the database
    await saveGoogleDriveToken(userId, {
      accessToken: "",
      refreshToken: null,
      expiresAt: null,
    });

    console.log(`[Google Drive] User ${userId} disconnected`);
  } catch (error) {
    console.error("[Google Drive] Error disconnecting:", error);
    throw new Error("Failed to disconnect Google Drive");
  }
}
