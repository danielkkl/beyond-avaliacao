import { protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import Stripe from "stripe";
import { createOrUpdateUserPlan } from "./db";
import { TRPCError } from "@trpc/server";
import { STRIPE_PRODUCTS } from "./stripe-products";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "");

export const stripeRouter = router({
  // Create checkout session for Premium plan
  createCheckoutSession: protectedProcedure
    .input(z.object({
      planType: z.enum(["monthly", "yearly"]),
      successUrl: z.string(),
      cancelUrl: z.string(),
    }))
    .mutation(async ({ ctx, input }) => {
      try {
        const user = ctx.user;
        if (!user) {
          throw new TRPCError({
            code: "UNAUTHORIZED",
            message: "User not authenticated",
          });
        }

        const priceId = input.planType === "monthly"
          ? STRIPE_PRODUCTS.PREMIUM_MONTHLY.priceId
          : STRIPE_PRODUCTS.PREMIUM_YEARLY.priceId;

        const session = await stripe.checkout.sessions.create({
          payment_method_types: ["card"],
          line_items: [
            {
              price: priceId,
              quantity: 1,
            },
          ],
          mode: "subscription",
          success_url: input.successUrl,
          cancel_url: input.cancelUrl,
          customer_email: user.email || undefined,
          client_reference_id: user.id.toString(),
          metadata: {
            user_id: user.id.toString(),
            customer_email: user.email || "",
            customer_name: user.name || "",
            plan_type: "premium",
          },
          allow_promotion_codes: true,
        });

        if (!session.url) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to create checkout session",
          });
        }

        return {
          sessionUrl: session.url,
          sessionId: session.id,
        };
      } catch (error) {
        console.error("Error creating checkout session:", error);
        if (error instanceof TRPCError) throw error;
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to create checkout session",
        });
      }
    }),

  // Get subscription status
  getSubscriptionStatus: protectedProcedure.query(async ({ ctx }) => {
    try {
      const user = ctx.user;
      if (!user) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "User not authenticated",
        });
      }

      // In a real app, you'd fetch this from your database
      // For now, return a placeholder
      return {
        status: "active",
        planType: "premium",
        currentPeriodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
      };
    } catch (error) {
      console.error("Error getting subscription status:", error);
      if (error instanceof TRPCError) throw error;
      throw new TRPCError({
        code: "INTERNAL_SERVER_ERROR",
        message: "Failed to get subscription status",
      });
    }
  }),

  // Cancel subscription
  cancelSubscription: protectedProcedure.mutation(async ({ ctx }) => {
    try {
      const user = ctx.user;
      if (!user) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "User not authenticated",
        });
      }

      // In a real app, you'd get the subscription ID from your database
      // For now, just update the plan to free
      await createOrUpdateUserPlan(user.id, {
        planType: "free",
        status: "cancelled",
      });

      return { success: true };
    } catch (error) {
      console.error("Error cancelling subscription:", error);
      if (error instanceof TRPCError) throw error;
      throw new TRPCError({
        code: "INTERNAL_SERVER_ERROR",
        message: "Failed to cancel subscription",
      });
    }
  }),
});
