import bcrypt from "bcryptjs";
import { getDb } from "./db";
import { users } from "../drizzle/schema";
import { eq } from "drizzle-orm";

export interface RegisterInput {
  email: string;
  password: string;
  name: string;
}

export interface LoginInput {
  email: string;
  password: string;
}

export interface AuthResponse {
  success: boolean;
  message: string;
  userId?: number;
  user?: {
    id: number;
    email: string;
    name: string;
  };
}

const SALT_ROUNDS = 10;

/**
 * Hash de senha seguro usando bcryptjs
 */
export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, SALT_ROUNDS);
}

/**
 * Verificar se a senha corresponde ao hash
 */
export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

/**
 * Registrar novo usuário com email/senha
 */
export async function registerUser(input: RegisterInput): Promise<AuthResponse> {
  try {
    const db = await getDb();
    if (!db) {
      return { success: false, message: "Banco de dados indisponível" };
    }

    // Validar entrada
    if (!input.email || !input.password || !input.name) {
      return { success: false, message: "Email, senha e nome são obrigatórios" };
    }

    // Validar formato de email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(input.email)) {
      return { success: false, message: "Email inválido" };
    }

    // Validar comprimento de senha
    if (input.password.length < 8) {
      return { success: false, message: "Senha deve ter no mínimo 8 caracteres" };
    }

    // Verificar se email já existe
    const existingUser = await db
      .select()
      .from(users)
      .where(eq(users.email, input.email))
      .limit(1);

    if (existingUser.length > 0) {
      return { success: false, message: "Email já registrado" };
    }

    // Hash da senha
    const passwordHash = await hashPassword(input.password);

    // Criar novo usuário
    const result = await db.insert(users).values({
      email: input.email,
      name: input.name,
      passwordHash,
      loginMethod: "email",
      emailVerified: true, // Simplificado: sem verificação de email por enquanto
      openId: `email_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    });

    const newUser = await db
      .select()
      .from(users)
      .where(eq(users.email, input.email))
      .limit(1);

    if (newUser.length === 0) {
      return { success: false, message: "Erro ao criar usuário" };
    }

    return {
      success: true,
      message: "Usuário registrado com sucesso",
      userId: newUser[0].id,
      user: {
        id: newUser[0].id,
        email: newUser[0].email || "",
        name: newUser[0].name || "",
      },
    };
  } catch (error) {
    console.error("[Auth] Erro ao registrar usuário:", error);
    return { success: false, message: "Erro ao registrar usuário" };
  }
}

/**
 * Login com email/senha
 */
export async function loginUser(input: LoginInput): Promise<AuthResponse> {
  try {
    const db = await getDb();
    if (!db) {
      return { success: false, message: "Banco de dados indisponível" };
    }

    // Validar entrada
    if (!input.email || !input.password) {
      return { success: false, message: "Email e senha são obrigatórios" };
    }

    // Buscar usuário por email
    const userList = await db
      .select()
      .from(users)
      .where(eq(users.email, input.email))
      .limit(1);

    if (userList.length === 0) {
      return { success: false, message: "Email ou senha inválidos" };
    }

    const user = userList[0];

    // Verificar se o usuário tem senha (não é OAuth)
    if (!user.passwordHash) {
      return { success: false, message: "Este email foi registrado com OAuth. Use o login social." };
    }

    // Verificar senha
    const passwordMatch = await verifyPassword(input.password, user.passwordHash);
    if (!passwordMatch) {
      return { success: false, message: "Email ou senha inválidos" };
    }

    // Atualizar lastSignedIn
    await db
      .update(users)
      .set({ lastSignedIn: new Date() })
      .where(eq(users.id, user.id));

    return {
      success: true,
      message: "Login realizado com sucesso",
      userId: user.id,
      user: {
        id: user.id,
        email: user.email || "",
        name: user.name || "",
      },
    };
  } catch (error) {
    console.error("[Auth] Erro ao fazer login:", error);
    return { success: false, message: "Erro ao fazer login" };
  }
}

/**
 * Obter usuário por email
 */
export async function getUserByEmail(email: string) {
  try {
    const db = await getDb();
    if (!db) return null;

    const userList = await db
      .select()
      .from(users)
      .where(eq(users.email, email))
      .limit(1);

    return userList.length > 0 ? userList[0] : null;
  } catch (error) {
    console.error("[Auth] Erro ao buscar usuário por email:", error);
    return null;
  }
}

/**
 * Obter usuário por ID
 */
export async function getUserById(id: number) {
  try {
    const db = await getDb();
    if (!db) return null;

    const userList = await db
      .select()
      .from(users)
      .where(eq(users.id, id))
      .limit(1);

    return userList.length > 0 ? userList[0] : null;
  } catch (error) {
    console.error("[Auth] Erro ao buscar usuário por ID:", error);
    return null;
  }
}
