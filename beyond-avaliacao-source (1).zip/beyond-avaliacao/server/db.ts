import { eq, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, fichas, userPlans, fichaUsage, googleDriveTokens } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ─── FICHAS HELPERS ───

export async function createFicha(userId: number, fichaData: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(fichas).values({
    userId,
    ...fichaData,
  });

  return result;
}

export async function getFichasByUserId(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.select().from(fichas).where(eq(fichas.userId, userId));
}

export async function getFichaById(fichaId: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.select().from(fichas).where(
    and(eq(fichas.id, fichaId), eq(fichas.userId, userId))
  );

  return result.length > 0 ? result[0] : undefined;
}

export async function updateFicha(fichaId: number, userId: number, fichaData: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.update(fichas).set(fichaData).where(
    and(eq(fichas.id, fichaId), eq(fichas.userId, userId))
  );
}

export async function deleteFicha(fichaId: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.delete(fichas).where(
    and(eq(fichas.id, fichaId), eq(fichas.userId, userId))
  );
}

// ─── USER PLANS HELPERS ───

export async function getUserPlan(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.select().from(userPlans).where(eq(userPlans.userId, userId));
  return result.length > 0 ? result[0] : null;
}

export async function createOrUpdateUserPlan(userId: number, planData: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const existing = await getUserPlan(userId);
  
  if (existing) {
    return await db.update(userPlans).set(planData).where(eq(userPlans.userId, userId));
  } else {
    return await db.insert(userPlans).values({
      userId,
      ...planData,
    });
  }
}

// ─── FICHA USAGE HELPERS ───

export async function getFichaUsageThisMonth(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth() + 1;

  const result = await db.select().from(fichaUsage).where(
    and(
      eq(fichaUsage.userId, userId),
      eq(fichaUsage.year, year),
      eq(fichaUsage.month, month)
    )
  );

  return result.length > 0 ? result[0].count : 0;
}

export async function incrementFichaUsage(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth() + 1;

  const existing = await db.select().from(fichaUsage).where(
    and(
      eq(fichaUsage.userId, userId),
      eq(fichaUsage.year, year),
      eq(fichaUsage.month, month)
    )
  );

  if (existing.length > 0) {
    return await db.update(fichaUsage).set({
      count: existing[0].count + 1,
    }).where(
      and(
        eq(fichaUsage.userId, userId),
        eq(fichaUsage.year, year),
        eq(fichaUsage.month, month)
      )
    );
  } else {
    return await db.insert(fichaUsage).values({
      userId,
      year,
      month,
      count: 1,
    });
  }
}

// ─── GOOGLE DRIVE TOKENS HELPERS ───

export async function getGoogleDriveToken(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.select().from(googleDriveTokens).where(eq(googleDriveTokens.userId, userId));
  return result.length > 0 ? result[0] : null;
}

export async function saveGoogleDriveToken(userId: number, tokenData: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const existing = await getGoogleDriveToken(userId);
  
  if (existing) {
    return await db.update(googleDriveTokens).set(tokenData).where(eq(googleDriveTokens.userId, userId));
  } else {
    return await db.insert(googleDriveTokens).values({
      userId,
      ...tokenData,
    });
  }
}
