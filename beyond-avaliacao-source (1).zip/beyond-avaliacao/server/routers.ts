import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { generateAndUploadFichaPDF } from "./pdf-generator";
import {
  createFicha,
  getFichasByUserId,
  getFichaById,
  updateFicha,
  deleteFicha,
  getUserPlan,
  createOrUpdateUserPlan,
  getFichaUsageThisMonth,
  incrementFichaUsage,
} from "./db";
import { TRPCError } from "@trpc/server";
import { stripeRouter } from "./stripe-router";
import { registerUser, loginUser } from "./auth.service";

export const appRouter = router({
  system: systemRouter,
  stripe: stripeRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    
    register: publicProcedure
      .input(z.object({
        email: z.string().email("Email inválido"),
        password: z.string().min(8, "Senha deve ter no mínimo 8 caracteres"),
        name: z.string().min(2, "Nome deve ter no mínimo 2 caracteres"),
      }))
      .mutation(async ({ input, ctx }) => {
        const result = await registerUser(input);
        
        if (!result.success) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: result.message,
          });
        }

        // Criar plano Free padrão
        if (result.userId) {
          await createOrUpdateUserPlan(result.userId, {
            planType: "free",
            status: "active",
            currentPeriodStart: new Date(),
            currentPeriodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
          });
        }

        return {
          success: true,
          message: result.message,
          userId: result.userId,
        };
      }),

    login: publicProcedure
      .input(z.object({
        email: z.string().email("Email inválido"),
        password: z.string().min(1, "Senha é obrigatória"),
      }))
      .mutation(async ({ input, ctx }) => {
        const result = await loginUser(input);
        
        if (!result.success) {
          throw new TRPCError({
            code: "UNAUTHORIZED",
            message: result.message,
          });
        }

        return {
          success: true,
          message: result.message,
          userId: result.userId,
          user: result.user,
        };
      }),

    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // ─── FICHAS ROUTER ───
  fichas: router({
    // List all fichas for the current user
    list: protectedProcedure.query(async ({ ctx }) => {
      try {
        return await getFichasByUserId(ctx.user.id);
      } catch (error) {
        console.error("Error listing fichas:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to list fichas",
        });
      }
    }),

    // Get a single ficha by ID
    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ ctx, input }) => {
        try {
          const ficha = await getFichaById(input.id, ctx.user.id);
          if (!ficha) {
            throw new TRPCError({
              code: "NOT_FOUND",
              message: "Ficha not found",
            });
          }
          return ficha;
        } catch (error) {
          console.error("Error getting ficha:", error);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to get ficha",
          });
        }
      }),

    // Create a new ficha
    create: protectedProcedure
      .input(z.object({
        nomePaciente: z.string(),
        dataNascimento: z.string().optional(),
        sexo: z.string().optional(),
        musculos: z.any().optional(),
        prescricoes: z.any().optional(),
        evolucoes: z.any().optional(),
      }).passthrough())
      .mutation(async ({ ctx, input }) => {
        try {
          // Check plan limits
          const plan = await getUserPlan(ctx.user.id);
          const planType = plan?.planType || "free";

          if (planType === "free") {
            const usage = await getFichaUsageThisMonth(ctx.user.id);
            if (usage >= 3) {
              throw new TRPCError({
                code: "FORBIDDEN",
                message: "Limite de 3 fichas/mês atingido no plano Free. Upgrade para Premium!",
              });
            }
          }

          // Create ficha
          const result = await createFicha(ctx.user.id, input);
          const fichaId = (result as any)[0]?.insertId || 0;
          
          // Generate and upload PDF
          try {
            const pdfResult = await generateAndUploadFichaPDF(ctx.user.id, fichaId, input);
            await updateFicha(fichaId, ctx.user.id, {
              pdfUrl: pdfResult.url,
            });
          } catch (pdfError) {
            console.error("Error generating PDF:", pdfError);
          }
          
          await incrementFichaUsage(ctx.user.id);

          return { success: true, id: fichaId };
        } catch (error) {
          if (error instanceof TRPCError) throw error;
          console.error("Error creating ficha:", error);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to create ficha",
          });
        }
      }),

    // Update a ficha
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        data: z.object({
          nomePaciente: z.string().optional(),
          dataNascimento: z.string().optional(),
          sexo: z.string().optional(),
          musculos: z.any().optional(),
          prescricoes: z.any().optional(),
          evolucoes: z.any().optional(),
          pdfUrl: z.string().optional(),
          googleDriveFileId: z.string().optional(),
        }).passthrough(),
      }))
      .mutation(async ({ ctx, input }) => {
        try {
          await updateFicha(input.id, ctx.user.id, input.data);
          return { success: true };
        } catch (error) {
          console.error("Error updating ficha:", error);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to update ficha",
          });
        }
      }),

    // Delete a ficha
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        try {
          await deleteFicha(input.id, ctx.user.id);
          return { success: true };
        } catch (error) {
          console.error("Error deleting ficha:", error);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to delete ficha",
          });
        }
      }),
  }),

  // ─── PLANS ROUTER ───
  plans: router({
    // Get current user's plan
    getCurrent: protectedProcedure.query(async ({ ctx }) => {
      try {
        const plan = await getUserPlan(ctx.user.id);
        return plan || { planType: "free", status: "active" };
      } catch (error) {
        console.error("Error getting plan:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to get plan",
        });
      }
    }),

    // Update plan (after Stripe payment)
    updatePlan: protectedProcedure
      .input(z.object({
        planType: z.enum(["free", "premium"]),
        stripeSubscriptionId: z.string().optional(),
        stripeCustomerId: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        try {
          await createOrUpdateUserPlan(ctx.user.id, {
            planType: input.planType,
            stripeSubscriptionId: input.stripeSubscriptionId,
            stripeCustomerId: input.stripeCustomerId,
            status: "active",
            currentPeriodStart: new Date(),
            currentPeriodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
          });
          return { success: true };
        } catch (error) {
          console.error("Error updating plan:", error);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to update plan",
          });
        }
      }),

    // Get usage stats
    getUsage: protectedProcedure.query(async ({ ctx }) => {
      try {
        const plan = await getUserPlan(ctx.user.id);
        const usage = await getFichaUsageThisMonth(ctx.user.id);
        const limit = plan?.planType === "premium" ? Infinity : 3;

        return {
          current: usage,
          limit,
          remaining: Math.max(0, limit - usage),
          planType: plan?.planType || "free",
        };
      } catch (error) {
        console.error("Error getting usage:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to get usage",
        });
      }
    }),
  }),
});

export type AppRouter = typeof appRouter;
