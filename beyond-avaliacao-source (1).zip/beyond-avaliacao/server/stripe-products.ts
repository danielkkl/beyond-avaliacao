/**
 * Stripe Products and Prices Configuration
 * These are the products and prices for AvaliaFisio plans
 */

export const STRIPE_PRODUCTS = {
  PREMIUM_MONTHLY: {
    name: "AvaliaFisio Premium - Mensal",
    description: "Acesso ilimitado a fichas, Google Drive integrado, suporte prioritário",
    price: 2999, // $29.99 em centavos
    currency: "usd",
    interval: "month",
    // You'll need to create these in Stripe Dashboard and update with actual IDs
    priceId: process.env.STRIPE_PREMIUM_MONTHLY_PRICE_ID || "price_1234567890",
  },
  PREMIUM_YEARLY: {
    name: "AvaliaFisio Premium - Anual",
    description: "Acesso ilimitado a fichas, Google Drive integrado, suporte prioritário",
    price: 29999, // $299.99 em centavos (desconto de ~17%)
    currency: "usd",
    interval: "year",
    priceId: process.env.STRIPE_PREMIUM_YEARLY_PRICE_ID || "price_0987654321",
  },
};

export const PLAN_LIMITS = {
  free: {
    fichasPerMonth: 3,
    googleDrive: false,
    prioritySupport: false,
  },
  premium: {
    fichasPerMonth: Infinity,
    googleDrive: true,
    prioritySupport: true,
  },
};
