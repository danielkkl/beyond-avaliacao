-- ============================================================================
-- BEYOND AVALIAÇÃO - Schema Completo do Banco de Dados
-- ============================================================================
-- Este arquivo contém toda a estrutura do banco de dados pronto para Vercel
-- Compatível com MySQL 8.0+
-- ============================================================================

-- ============================================================================
-- 1. CRIAR BANCO DE DADOS
-- ============================================================================

CREATE DATABASE IF NOT EXISTS beyond_avaliacao CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE beyond_avaliacao;

-- ============================================================================
-- 2. TABELA DE USUÁRIOS
-- ============================================================================

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(255) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  name VARCHAR(255) NOT NULL,
  cpf VARCHAR(14) UNIQUE,
  crefito VARCHAR(20),
  phone VARCHAR(20),
  avatar_url TEXT,
  plan_id INT DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  last_login TIMESTAMP,
  is_active BOOLEAN DEFAULT TRUE,
  INDEX idx_email (email),
  INDEX idx_plan_id (plan_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 3. TABELA DE PLANOS
-- ============================================================================

CREATE TABLE plans (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(50) NOT NULL UNIQUE,
  description TEXT,
  price DECIMAL(10, 2),
  currency VARCHAR(3) DEFAULT 'BRL',
  max_fichas_per_month INT,
  has_google_drive BOOLEAN DEFAULT FALSE,
  has_reports BOOLEAN DEFAULT FALSE,
  has_export BOOLEAN DEFAULT FALSE,
  stripe_price_id VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 4. TABELA DE ASSINATURAS
-- ============================================================================

CREATE TABLE subscriptions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  plan_id INT NOT NULL,
  stripe_subscription_id VARCHAR(255) UNIQUE,
  stripe_customer_id VARCHAR(255),
  status ENUM('active', 'canceled', 'past_due', 'paused') DEFAULT 'active',
  current_period_start DATE,
  current_period_end DATE,
  cancel_at_period_end BOOLEAN DEFAULT FALSE,
  canceled_at TIMESTAMP NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (plan_id) REFERENCES plans(id),
  INDEX idx_user_id (user_id),
  INDEX idx_stripe_subscription_id (stripe_subscription_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 5. TABELA DE PACIENTES
-- ============================================================================

CREATE TABLE patients (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  name VARCHAR(255) NOT NULL,
  cpf VARCHAR(14) UNIQUE,
  email VARCHAR(255),
  phone VARCHAR(20),
  date_of_birth DATE,
  gender ENUM('M', 'F', 'O'),
  marital_status VARCHAR(50),
  ethnicity VARCHAR(50),
  profession VARCHAR(255),
  address TEXT,
  city VARCHAR(100),
  state VARCHAR(2),
  zip_code VARCHAR(10),
  health_plan VARCHAR(255),
  referring_doctor VARCHAR(255),
  clinical_diagnosis TEXT,
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_user_id (user_id),
  INDEX idx_cpf (cpf)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 6. TABELA DE FICHAS DE AVALIAÇÃO
-- ============================================================================

CREATE TABLE fichas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  patient_id INT NOT NULL,
  assessment_date DATE NOT NULL,
  consultation_date DATE,
  record_number VARCHAR(50),
  
  -- SEÇÃO 1: IDENTIFICAÇÃO
  patient_name VARCHAR(255),
  patient_cpf VARCHAR(14),
  patient_email VARCHAR(255),
  patient_phone VARCHAR(20),
  patient_address TEXT,
  patient_profession VARCHAR(255),
  patient_health_plan VARCHAR(255),
  
  -- SEÇÃO 2: HÁBITOS DE VIDA
  diet VARCHAR(50),
  sleep_quality VARCHAR(50),
  hydration VARCHAR(50),
  daily_routine TEXT,
  physical_activity VARCHAR(50),
  medications TEXT,
  smoking ENUM('yes', 'no'),
  alcohol_use ENUM('yes', 'no'),
  stress_level ENUM('yes', 'no'),
  repetitive_work ENUM('yes', 'no'),
  repetitive_work_details TEXT,
  sports_history ENUM('yes', 'no'),
  sports_history_details TEXT,
  
  -- SEÇÃO 3: SINAIS VITAIS
  blood_pressure VARCHAR(20),
  heart_rate INT,
  respiratory_rate INT,
  oxygen_saturation DECIMAL(5, 2),
  temperature DECIMAL(5, 2),
  blood_glucose INT,
  weight DECIMAL(6, 2),
  height INT,
  imc DECIMAL(5, 2),
  imc_classification VARCHAR(50),
  
  -- SEÇÃO 4: ANAMNESE
  current_disease_history TEXT,
  past_disease_history TEXT,
  pain_eva INT,
  pain_onset VARCHAR(100),
  pain_type VARCHAR(100),
  pain_irradiation TEXT,
  pain_improvement_factors TEXT,
  pain_worsening_factors TEXT,
  previous_surgeries TEXT,
  
  -- SEÇÃO 5: EXAME FÍSICO
  inspection TEXT,
  palpation TEXT,
  static_posture TEXT,
  dynamic_posture TEXT,
  gait TEXT,
  perimetry TEXT,
  special_tests TEXT,
  
  -- SEÇÃO 6: MAPA DA DOR
  pain_map_data LONGTEXT,
  
  -- SEÇÃO 7: ADM/FORÇA
  adm_force_data LONGTEXT,
  
  -- SEÇÃO 8: PRESCRIÇÕES
  prescriptions_data LONGTEXT,
  
  -- SEÇÃO 9: ESTRATÉGIAS
  short_term_strategy TEXT,
  medium_term_strategy TEXT,
  long_term_strategy TEXT,
  
  -- SEÇÃO 10: EVOLUÇÃO
  evolution_data LONGTEXT,
  
  -- SEÇÃO 11: CONSENTIMENTO
  consent_photos BOOLEAN DEFAULT FALSE,
  consent_absence_policy BOOLEAN DEFAULT FALSE,
  consent_session_replacement BOOLEAN DEFAULT FALSE,
  
  -- SEÇÃO 12: ASSINATURAS
  patient_signature LONGTEXT,
  therapist_signature LONGTEXT,
  
  -- METADADOS
  status ENUM('draft', 'completed', 'archived') DEFAULT 'draft',
  pdf_url TEXT,
  google_drive_file_id VARCHAR(255),
  is_synced_to_drive BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
  INDEX idx_user_id (user_id),
  INDEX idx_patient_id (patient_id),
  INDEX idx_assessment_date (assessment_date),
  INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 7. TABELA DE TOKENS DO GOOGLE DRIVE
-- ============================================================================

CREATE TABLE google_drive_tokens (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL UNIQUE,
  access_token TEXT NOT NULL,
  refresh_token TEXT,
  token_expiry TIMESTAMP,
  folder_id VARCHAR(255),
  is_connected BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 8. TABELA DE HISTÓRICO DE FICHAS
-- ============================================================================

CREATE TABLE ficha_history (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ficha_id INT NOT NULL,
  user_id INT NOT NULL,
  action VARCHAR(50),
  changes_data LONGTEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (ficha_id) REFERENCES fichas(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_ficha_id (ficha_id),
  INDEX idx_user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 9. TABELA DE PAGAMENTOS
-- ============================================================================

CREATE TABLE payments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  subscription_id INT,
  stripe_payment_intent_id VARCHAR(255) UNIQUE,
  amount DECIMAL(10, 2) NOT NULL,
  currency VARCHAR(3) DEFAULT 'BRL',
  status ENUM('pending', 'succeeded', 'failed', 'canceled') DEFAULT 'pending',
  payment_method VARCHAR(50),
  description TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (subscription_id) REFERENCES subscriptions(id),
  INDEX idx_user_id (user_id),
  INDEX idx_stripe_payment_intent_id (stripe_payment_intent_id),
  INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 10. TABELA DE LOGS
-- ============================================================================

CREATE TABLE logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  action VARCHAR(255),
  resource_type VARCHAR(100),
  resource_id INT,
  details TEXT,
  ip_address VARCHAR(45),
  user_agent TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_user_id (user_id),
  INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 11. INSERIR PLANOS PADRÃO
-- ============================================================================

INSERT INTO plans (name, description, price, max_fichas_per_month, has_google_drive, has_reports, has_export, stripe_price_id) VALUES
('Free', 'Plano gratuito com limite de fichas', 0.00, 3, FALSE, FALSE, FALSE, NULL),
('Premium', 'Plano premium com fichas ilimitadas', 49.90, NULL, TRUE, TRUE, TRUE, 'price_1234567890'),
('Enterprise', 'Plano enterprise com suporte dedicado', 199.90, NULL, TRUE, TRUE, TRUE, 'price_0987654321');

-- ============================================================================
-- 12. CRIAR ÍNDICES ADICIONAIS PARA PERFORMANCE
-- ============================================================================

CREATE INDEX idx_fichas_user_patient ON fichas(user_id, patient_id);
CREATE INDEX idx_fichas_created_at ON fichas(created_at);
CREATE INDEX idx_patients_user_id ON patients(user_id);
CREATE INDEX idx_subscriptions_user_plan ON subscriptions(user_id, plan_id);
CREATE INDEX idx_payments_user_status ON payments(user_id, status);

-- ============================================================================
-- 13. CRIAR VIEWS ÚTEIS
-- ============================================================================

-- View: Fichas do mês atual por usuário
CREATE VIEW fichas_mes_atual AS
SELECT 
  u.id as user_id,
  u.email,
  COUNT(f.id) as total_fichas,
  p.max_fichas_per_month,
  (p.max_fichas_per_month - COUNT(f.id)) as fichas_restantes
FROM users u
LEFT JOIN subscriptions s ON u.id = s.user_id AND s.status = 'active'
LEFT JOIN plans p ON s.plan_id = p.id
LEFT JOIN fichas f ON u.id = f.user_id 
  AND YEAR(f.created_at) = YEAR(CURDATE())
  AND MONTH(f.created_at) = MONTH(CURDATE())
GROUP BY u.id, u.email, p.max_fichas_per_month;

-- View: Usuários ativos com assinatura
CREATE VIEW usuarios_premium AS
SELECT 
  u.id,
  u.email,
  u.name,
  p.name as plan_name,
  s.current_period_end,
  s.status
FROM users u
LEFT JOIN subscriptions s ON u.id = s.user_id AND s.status = 'active'
LEFT JOIN plans p ON s.plan_id = p.id
WHERE p.name != 'Free';

-- ============================================================================
-- 14. DADOS DE EXEMPLO (OPCIONAL)
-- ============================================================================

-- Usuário de teste
INSERT INTO users (email, password_hash, name, crefito, plan_id) VALUES
('teste@beyondavaliacao.com.br', '$2b$10$YourHashedPasswordHere', 'João Silva', 'CREFITO 10 389091-F', 1);

-- Paciente de teste
INSERT INTO patients (user_id, name, cpf, email, phone, date_of_birth, gender, profession) VALUES
(1, 'Maria Santos', '123.456.789-00', 'maria@example.com', '(11) 98765-4321', '1990-05-15', 'F', 'Professora');

-- ============================================================================
-- 15. VERIFICAR INTEGRIDADE
-- ============================================================================

-- Verificar tabelas criadas
SHOW TABLES;

-- Verificar estrutura de uma tabela
DESCRIBE users;
DESCRIBE fichas;
DESCRIBE subscriptions;

-- ============================================================================
-- FIM DO SCRIPT
-- ============================================================================
-- 
-- PRÓXIMOS PASSOS:
-- 1. Copie este script completo
-- 2. Acesse o Vercel PostgreSQL ou Railway MySQL
-- 3. Cole o script no console SQL
-- 4. Execute
-- 5. Seu banco de dados está pronto!
--
-- VARIÁVEIS DE AMBIENTE NECESSÁRIAS:
-- DATABASE_URL=mysql://username:password@host:3306/beyond_avaliacao
--
-- ============================================================================
