#!/bin/bash

# Script de build para produção
set -e

echo "🔨 Iniciando build do AvaliaFisio..."

# Instalar dependências
echo "📦 Instalando dependências..."
pnpm install --frozen-lockfile

# Build do projeto
echo "🏗️  Compilando projeto..."
pnpm run build

# Verificar se build foi bem-sucedido
if [ -d "dist" ]; then
    echo "✅ Build concluído com sucesso!"
    echo "📁 Arquivos em: ./dist"
else
    echo "❌ Erro no build!"
    exit 1
fi
