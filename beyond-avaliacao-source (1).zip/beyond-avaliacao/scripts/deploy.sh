#!/bin/bash

# Script de deploy com Docker Compose
set -e

echo "🚀 Iniciando deployment do AvaliaFisio..."

# Verificar se Docker está instalado
if ! command -v docker &> /dev/null; then
    echo "❌ Docker não está instalado!"
    exit 1
fi

if ! command -v docker-compose &> /dev/null; then
    echo "❌ Docker Compose não está instalado!"
    exit 1
fi

# Parar containers antigos
echo "🛑 Parando containers antigos..."
docker-compose down || true

# Build da imagem
echo "🔨 Construindo imagem Docker..."
docker-compose build

# Iniciar containers
echo "▶️  Iniciando containers..."
docker-compose up -d

# Aguardar inicialização
echo "⏳ Aguardando inicialização..."
sleep 5

# Verificar status
echo "🔍 Verificando status..."
docker-compose ps

# Health check
echo "💚 Testando health check..."
if curl -f http://localhost:3000 > /dev/null 2>&1; then
    echo "✅ Deployment concluído com sucesso!"
    echo "🌐 Acesse em: http://localhost:3000"
else
    echo "⚠️  Aplicação ainda está iniciando, tente novamente em alguns segundos"
fi

echo ""
echo "📋 Comandos úteis:"
echo "  Ver logs:        docker-compose logs -f"
echo "  Parar:           docker-compose down"
echo "  Reiniciar:       docker-compose restart"
echo "  Status:          docker-compose ps"
