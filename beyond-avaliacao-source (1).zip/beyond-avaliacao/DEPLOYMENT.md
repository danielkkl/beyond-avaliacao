# Deployment - AvaliaFisio

Guia completo para fazer deploy do AvaliaFisio em produção usando Docker Compose.

## Pré-requisitos

- Docker 20.10+
- Docker Compose 2.0+
- Pelo menos 2GB de RAM disponível
- Porta 3000 disponível (ou configure outra no docker-compose.yml)

## Instalação Rápida

### 1. Clonar/Extrair o projeto

```bash
cd /caminho/para/avaliai-fisio
```

### 2. Construir e iniciar os containers

```bash
docker-compose up -d
```

O aplicativo estará disponível em `http://localhost:3000`

### 3. Parar os containers

```bash
docker-compose down
```

## Configuração Avançada

### Alterar a porta

Edite `docker-compose.yml`:

```yaml
ports:
  - "8080:3000"  # Acesso em http://localhost:8080
```

### Variáveis de Ambiente

Crie um arquivo `.env` na raiz do projeto:

```bash
NODE_ENV=production
PORT=3000
VITE_APP_TITLE=AvaliaFisio
```

### Usar com Nginx (Reverse Proxy)

```nginx
server {
    listen 80;
    server_name seu-dominio.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

### Usar com SSL/TLS (Let's Encrypt)

```bash
# Instalar Certbot
sudo apt-get install certbot python3-certbot-nginx

# Gerar certificado
sudo certbot certonly --standalone -d seu-dominio.com

# Configurar Nginx com SSL
server {
    listen 443 ssl http2;
    server_name seu-dominio.com;

    ssl_certificate /etc/letsencrypt/live/seu-dominio.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/seu-dominio.com/privkey.pem;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

## Monitoramento

### Ver logs

```bash
docker-compose logs -f avaliai-fisio
```

### Ver status dos containers

```bash
docker-compose ps
```

### Health check

```bash
curl http://localhost:3000
```

## Backup e Restauração

### Backup do projeto

```bash
tar -czf avaliai-fisio-backup.tar.gz /caminho/para/avaliai-fisio
```

### Restaurar do backup

```bash
tar -xzf avaliai-fisio-backup.tar.gz -C /
docker-compose up -d
```

## Troubleshooting

### Container não inicia

```bash
docker-compose logs avaliai-fisio
```

### Porta já em uso

```bash
# Encontrar processo usando porta 3000
lsof -i :3000

# Ou alterar a porta no docker-compose.yml
```

### Permissões de arquivo

```bash
chmod -R 755 /caminho/para/avaliai-fisio
```

## Performance em Produção

- Use um reverse proxy (Nginx/Apache) para melhor performance
- Configure SSL/TLS para segurança
- Considere usar um load balancer se tiver múltiplas instâncias
- Monitore logs e recursos regularmente

## Suporte

Para problemas ou dúvidas, consulte a documentação do Docker:
- https://docs.docker.com/
- https://docs.docker.com/compose/
