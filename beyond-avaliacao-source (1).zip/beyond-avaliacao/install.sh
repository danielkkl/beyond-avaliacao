#!/bin/bash

################################################################################
#                                                                              #
#                    BEYOND AVALIAÇÃO - Script de Instalação                  #
#                                                                              #
#  Este script automatiza a instalação completa do Beyond Avaliação           #
#  Funciona em macOS, Linux e Windows (WSL)                                   #
#                                                                              #
################################################################################

set -e  # Exit on error

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Funções de output
print_header() {
    echo -e "${BLUE}═══════════════════════════════════════════════════════════${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}═══════════════════════════════════════════════════════════${NC}"
}

print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

print_info() {
    echo -e "${YELLOW}ℹ $1${NC}"
}

# Verificar se está rodando como root
check_root() {
    if [[ $EUID -eq 0 ]]; then
        print_error "Este script NÃO deve ser executado como root"
        exit 1
    fi
}

# Detectar sistema operacional
detect_os() {
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        OS="linux"
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        OS="macos"
    elif [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "cygwin" ]]; then
        OS="windows"
    else
        OS="unknown"
    fi
    print_info "Sistema operacional detectado: $OS"
}

# Verificar dependências
check_dependencies() {
    print_header "Verificando Dependências"
    
    # Verificar Node.js
    if command -v node &> /dev/null; then
        NODE_VERSION=$(node -v)
        print_success "Node.js encontrado: $NODE_VERSION"
    else
        print_error "Node.js não encontrado. Instale em https://nodejs.org"
        exit 1
    fi
    
    # Verificar npm
    if command -v npm &> /dev/null; then
        NPM_VERSION=$(npm -v)
        print_success "npm encontrado: $NPM_VERSION"
    else
        print_error "npm não encontrado"
        exit 1
    fi
    
    # Verificar pnpm
    if command -v pnpm &> /dev/null; then
        PNPM_VERSION=$(pnpm -v)
        print_success "pnpm encontrado: $PNPM_VERSION"
    else
        print_info "pnpm não encontrado. Instalando..."
        npm install -g pnpm
        print_success "pnpm instalado"
    fi
    
    # Verificar Git
    if command -v git &> /dev/null; then
        GIT_VERSION=$(git --version)
        print_success "Git encontrado: $GIT_VERSION"
    else
        print_error "Git não encontrado. Instale em https://git-scm.com"
        exit 1
    fi
}

# Clonar repositório
clone_repository() {
    print_header "Clonando Repositório"
    
    read -p "Cole o URL do repositório Git (ou pressione Enter para pular): " REPO_URL
    
    if [ -z "$REPO_URL" ]; then
        print_info "Pulando clonagem do repositório"
        return
    fi
    
    read -p "Diretório de destino (padrão: ./beyond-avaliacao): " DEST_DIR
    DEST_DIR=${DEST_DIR:-./beyond-avaliacao}
    
    if [ -d "$DEST_DIR" ]; then
        print_error "Diretório $DEST_DIR já existe"
        exit 1
    fi
    
    print_info "Clonando $REPO_URL para $DEST_DIR..."
    git clone "$REPO_URL" "$DEST_DIR"
    cd "$DEST_DIR"
    
    print_success "Repositório clonado com sucesso"
}

# Instalar dependências
install_dependencies() {
    print_header "Instalando Dependências"
    
    print_info "Instalando dependências com pnpm..."
    pnpm install
    
    print_success "Dependências instaladas"
}

# Configurar variáveis de ambiente
setup_env() {
    print_header "Configurando Variáveis de Ambiente"
    
    if [ -f ".env.local" ]; then
        print_info ".env.local já existe"
        read -p "Deseja sobrescrever? (s/n): " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Ss]$ ]]; then
            return
        fi
    fi
    
    cat > .env.local << 'EOF'
# ============================================================================
# BANCO DE DADOS
# ============================================================================
# Formato: mysql://username:password@host:port/database
# Exemplo: mysql://root:password@localhost:3306/beyond_avaliacao
DATABASE_URL=

# ============================================================================
# STRIPE (Pagamento)
# ============================================================================
# Obtenha em: https://dashboard.stripe.com/apikeys
STRIPE_SECRET_KEY=
STRIPE_PUBLISHABLE_KEY=
STRIPE_WEBHOOK_SECRET=

# ============================================================================
# GOOGLE DRIVE (Backup)
# ============================================================================
# Obtenha em: https://console.cloud.google.com
GOOGLE_CLIENT_ID=
GOOGLE_CLIENT_SECRET=

# ============================================================================
# JWT (Autenticação)
# ============================================================================
# Gere uma chave aleatória forte
JWT_SECRET=

# ============================================================================
# NODE
# ============================================================================
NODE_ENV=development
PORT=3000

# ============================================================================
# VERCEL (Opcional)
# ============================================================================
VERCEL_URL=
EOF
    
    print_success ".env.local criado"
    print_info "Abra .env.local e preencha as variáveis de ambiente"
    
    read -p "Pressione Enter para continuar..."
}

# Configurar banco de dados
setup_database() {
    print_header "Configurando Banco de Dados"
    
    read -p "Deseja importar o schema do banco de dados? (s/n): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Ss]$ ]]; then
        print_info "Pulando importação do banco de dados"
        return
    fi
    
    if [ ! -f "database_schema.sql" ]; then
        print_error "Arquivo database_schema.sql não encontrado"
        return
    fi
    
    read -p "Host do banco de dados: " DB_HOST
    read -p "Usuário do banco de dados: " DB_USER
    read -sp "Senha do banco de dados: " DB_PASS
    echo
    read -p "Nome do banco de dados: " DB_NAME
    
    print_info "Importando schema..."
    mysql -h "$DB_HOST" -u "$DB_USER" -p"$DB_PASS" "$DB_NAME" < database_schema.sql
    
    print_success "Banco de dados configurado"
}

# Executar migrações
run_migrations() {
    print_header "Executando Migrações"
    
    if [ -f "package.json" ]; then
        if grep -q '"db:push"' package.json; then
            print_info "Executando migrações com Drizzle..."
            pnpm db:push
            print_success "Migrações executadas"
        fi
    fi
}

# Compilar aplicação
build_app() {
    print_header "Compilando Aplicação"
    
    print_info "Compilando frontend e backend..."
    pnpm build
    
    print_success "Aplicação compilada com sucesso"
}

# Iniciar servidor de desenvolvimento
start_dev() {
    print_header "Iniciando Servidor de Desenvolvimento"
    
    read -p "Deseja iniciar o servidor de desenvolvimento? (s/n): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Ss]$ ]]; then
        print_info "Pulando início do servidor"
        return
    fi
    
    print_info "Iniciando servidor em http://localhost:3000"
    pnpm dev
}

# Deploy na Vercel
deploy_vercel() {
    print_header "Deploy na Vercel"
    
    read -p "Deseja fazer deploy na Vercel? (s/n): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Ss]$ ]]; then
        print_info "Pulando deploy"
        return
    fi
    
    if ! command -v vercel &> /dev/null; then
        print_info "Vercel CLI não encontrada. Instalando..."
        npm install -g vercel
    fi
    
    print_info "Iniciando deploy na Vercel..."
    vercel
    
    print_success "Deploy concluído!"
}

# Menu principal
main_menu() {
    print_header "BEYOND AVALIAÇÃO - Instalação"
    
    echo "Escolha uma opção:"
    echo "1) Instalação Completa (recomendado)"
    echo "2) Instalar Dependências"
    echo "3) Configurar Variáveis de Ambiente"
    echo "4) Configurar Banco de Dados"
    echo "5) Executar Migrações"
    echo "6) Compilar Aplicação"
    echo "7) Iniciar Servidor de Desenvolvimento"
    echo "8) Deploy na Vercel"
    echo "9) Sair"
    
    read -p "Opção: " option
    
    case $option in
        1)
            check_dependencies
            setup_env
            setup_database
            run_migrations
            build_app
            start_dev
            ;;
        2)
            install_dependencies
            ;;
        3)
            setup_env
            ;;
        4)
            setup_database
            ;;
        5)
            run_migrations
            ;;
        6)
            build_app
            ;;
        7)
            start_dev
            ;;
        8)
            deploy_vercel
            ;;
        9)
            print_info "Saindo..."
            exit 0
            ;;
        *)
            print_error "Opção inválida"
            main_menu
            ;;
    esac
}

# Executar script
run_script() {
    clear
    print_header "BEYOND AVALIAÇÃO - Script de Instalação"
    
    check_root
    detect_os
    
    # Se for primeira execução, fazer instalação completa
    if [ ! -f "package.json" ]; then
        print_info "Primeira execução detectada"
        clone_repository
    fi
    
    main_menu
}

# Executar
run_script
