import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean, decimal, json } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }).unique(),
  passwordHash: text("passwordHash"),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  emailVerified: boolean("emailVerified").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── USER PLANS ───
export const userPlans = mysqlTable("userPlans", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  planType: mysqlEnum("planType", ["free", "premium"]).default("free").notNull(),
  stripeSubscriptionId: varchar("stripeSubscriptionId", { length: 255 }),
  stripeCustomerId: varchar("stripeCustomerId", { length: 255 }),
  status: mysqlEnum("status", ["active", "inactive", "cancelled"]).default("active").notNull(),
  currentPeriodStart: timestamp("currentPeriodStart"),
  currentPeriodEnd: timestamp("currentPeriodEnd"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type UserPlan = typeof userPlans.$inferSelect;
export type InsertUserPlan = typeof userPlans.$inferInsert;

// ─── FICHAS (EVALUATIONS) ───
export const fichas = mysqlTable("fichas", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  
  // Identificação
  nomePaciente: text("nomePaciente"),
  dataNascimento: varchar("dataNascimento", { length: 10 }),
  idadeAtual: int("idadeAtual"),
  sexo: varchar("sexo", { length: 50 }),
  estadoCivil: varchar("estadoCivil", { length: 50 }),
  perfilEtnico: varchar("perfilEtnico", { length: 100 }),
  profissao: text("profissao"),
  diagnosticoClinico: text("diagnosticoClinico"),
  nomeMedico: text("nomeMedico"),
  planoSaude: varchar("planoSaude", { length: 100 }),
  consultor: varchar("consultor", { length: 255 }),
  telefone: varchar("telefone", { length: 20 }),
  email: varchar("email", { length: 320 }),
  endereco: text("endereco"),
  cpf: varchar("cpf", { length: 14 }),
  numeroProntuario: varchar("numeroProntuario", { length: 100 }),
  dataAvaliacao: varchar("dataAvaliacao", { length: 10 }),
  numeroAtendimentos: int("numeroAtendimentos"),

  // Hábitos de Vida
  alimentacao: text("alimentacao"),
  sono: text("sono"),
  ingestaoHidrica: text("ingestaoHidrica"),
  rotinaDiaria: text("rotinaDiaria"),
  atividadeFisica: text("atividadeFisica"),
  medicamentos: text("medicamentos"),
  tabagismo: varchar("tabagismo", { length: 50 }),
  etilismo: varchar("etilismo", { length: 50 }),
  estresse: varchar("estresse", { length: 50 }),
  trabalhoRepetitivo: text("trabalhoRepetitivo"),
  historicoEsportivo: text("historicoEsportivo"),

  // Sinais Vitais
  pa: varchar("pa", { length: 20 }),
  fc: varchar("fc", { length: 20 }),
  fr: varchar("fr", { length: 20 }),
  satO2: varchar("satO2", { length: 20 }),
  temperatura: varchar("temperatura", { length: 20 }),
  peso: decimal("peso", { precision: 5, scale: 2 }),
  altura: decimal("altura", { precision: 4, scale: 2 }),
  imc: decimal("imc", { precision: 5, scale: 2 }),
  classificacaoIMC: varchar("classificacaoIMC", { length: 50 }),
  fcMax: int("fcMax"),
  zonaTreino: varchar("zonaTreino", { length: 50 }),
  frMax: int("frMax"),
  glicemia: varchar("glicemia", { length: 20 }),

  // Anamnese
  hda: text("hda"),
  hdp: text("hdp"),
  eva: int("eva"),
  inicioDor: text("inicioDor"),
  tipoDor: text("tipoDor"),
  irradiacao: text("irradiacao"),
  fatoresMelhora: text("fatoresMelhora"),
  fatoresPiora: text("fatoresPiora"),
  cirurgias: text("cirurgias"),

  // Avaliação Física
  inspecao: text("inspecao"),
  palpacao: text("palpacao"),
  sensibilidade: text("sensibilidade"),
  posturaEstatica: text("posturaEstatica"),
  posturaDinamica: text("posturaDinamica"),
  marcha: text("marcha"),
  perimetria: text("perimetria"),
  testesEspeciais: text("testesEspeciais"),

  // Estratégias
  estrategiasCurto: text("estrategiasCurto"),
  estrategiasMedio: text("estrategiasMedio"),
  estrategiasLongo: text("estrategiasLongo"),

  // Termo
  aceitoTermo: boolean("aceitoTermo").default(false),

  // Dados dinâmicos (JSON)
  musculos: json("musculos"),
  prescricoes: json("prescricoes"),
  evolucoes: json("evolucoes"),

  // PDF e integração
  pdfUrl: text("pdfUrl"),
  googleDriveFileId: varchar("googleDriveFileId", { length: 255 }),

  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Ficha = typeof fichas.$inferSelect;
export type InsertFicha = typeof fichas.$inferInsert;

// ─── GOOGLE DRIVE TOKENS ───
export const googleDriveTokens = mysqlTable("googleDriveTokens", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  accessToken: text("accessToken").notNull(),
  refreshToken: text("refreshToken"),
  expiresAt: timestamp("expiresAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type GoogleDriveToken = typeof googleDriveTokens.$inferSelect;
export type InsertGoogleDriveToken = typeof googleDriveTokens.$inferInsert;

// ─── FICHA USAGE TRACKING ───
export const fichaUsage = mysqlTable("fichaUsage", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  year: int("year").notNull(),
  month: int("month").notNull(),
  count: int("count").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type FichaUsage = typeof fichaUsage.$inferSelect;
export type InsertFichaUsage = typeof fichaUsage.$inferInsert;
