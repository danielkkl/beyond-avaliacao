# ✅ Checklist de Deploy - Beyond Avaliação

## 🎯 Antes de Fazer Deploy

### Preparação do Repositório
- [ ] Código commitado no Git
- [ ] Nenhum arquivo sensível (.env com valores reais, chaves privadas)
- [ ] `.gitignore` contém: `.env.local`, `node_modules/`, `dist/`, `.env*`
- [ ] `README.md` atualizado com instruções
- [ ] `package.json` com versão correta

### Arquivos de Configuração
- [ ] `netlify.toml` presente e correto
- [ ] `.env.example` com todas as variáveis
- [ ] `DEPLOY_NETLIFY.md` documentado
- [ ] `SETUP_NETLIFY.sh` executável

### Build Local
- [ ] `pnpm install` executa sem erros
- [ ] `pnpm build` gera `client/dist` sem erros
- [ ] Nenhum erro de TypeScript
- [ ] Nenhum warning crítico

### Dependências
- [ ] Todas as dependências em `package.json`
- [ ] Nenhuma dependência local (relative paths)
- [ ] Versões compatíveis com Node.js 18+
- [ ] `pnpm-lock.yaml` commitado

---

## 🔐 Credenciais e Segurança

### Banco de Dados
- [ ] Banco MySQL criado
- [ ] Schema importado (`database_schema.sql`)
- [ ] Usuário com permissões corretas
- [ ] Backup realizado
- [ ] DATABASE_URL testado localmente

### Stripe
- [ ] Conta Stripe criada
- [ ] API Keys obtidas (Secret e Publishable)
- [ ] Webhook criado e testado
- [ ] Webhook Secret obtido
- [ ] Modo teste ativado (sk_test_, pk_test_)

### Google Drive
- [ ] Projeto Google Cloud criado
- [ ] Google Drive API ativada
- [ ] OAuth 2.0 Client ID criado
- [ ] Client ID e Secret obtidos
- [ ] Redirect URI configurado

### JWT
- [ ] JWT_SECRET gerado (mínimo 32 caracteres)
- [ ] JWT_SECRET é aleatório e forte
- [ ] JWT_SECRET não está em código

### Outras Chaves
- [ ] SendGrid API Key (se usar email)
- [ ] Sentry DSN (se usar monitoramento)
- [ ] Google Analytics ID (se usar analytics)

---

## 🌐 Netlify

### Conta e Projeto
- [ ] Conta Netlify criada
- [ ] Repositório GitHub conectado
- [ ] Projeto criado no Netlify
- [ ] Build command correto: `pnpm install && pnpm build`
- [ ] Publish directory correto: `client/dist`

### Variáveis de Ambiente
- [ ] DATABASE_URL adicionada
- [ ] STRIPE_SECRET_KEY adicionada
- [ ] STRIPE_PUBLISHABLE_KEY adicionada
- [ ] STRIPE_WEBHOOK_SECRET adicionada
- [ ] GOOGLE_CLIENT_ID adicionada
- [ ] GOOGLE_CLIENT_SECRET adicionada
- [ ] JWT_SECRET adicionada
- [ ] NODE_ENV = production

### Build e Deploy
- [ ] Build bem-sucedido (sem erros)
- [ ] Deploy bem-sucedido
- [ ] Site acessível via URL Netlify
- [ ] Logs sem erros críticos

---

## 🧪 Testes Pós-Deploy

### Landing Page
- [ ] Página carrega sem erros
- [ ] Imagens carregam corretamente
- [ ] Links funcionam
- [ ] Responsivo em mobile
- [ ] Performance aceitável

### Autenticação
- [ ] Página de registro acessível
- [ ] Registro com novo usuário funciona
- [ ] Email de confirmação enviado (se configurado)
- [ ] Login com credenciais funciona
- [ ] Logout funciona
- [ ] Sessão persiste após reload

### Ficha de Avaliação
- [ ] Criar nova ficha funciona
- [ ] Preencher campos funciona
- [ ] Cálculos automáticos funcionam (IMC, FC Máx, etc)
- [ ] Mapa da dor interativo funciona
- [ ] Salvar ficha funciona
- [ ] Editar ficha funciona
- [ ] Deletar ficha funciona

### Dashboard
- [ ] Dashboard carrega
- [ ] Estatísticas aparecem
- [ ] Gráficos renderizam
- [ ] Pacientes listados
- [ ] Busca/filtro funciona

### Pagamento (Stripe)
- [ ] Página de upgrade acessível
- [ ] Planos aparecem corretamente
- [ ] Botão "Assinar" funciona
- [ ] Redirecionamento para Stripe funciona
- [ ] Checkout Stripe abre
- [ ] Cartão de teste aceito: 4242 4242 4242 4242
- [ ] Após pagamento, upgrade aplicado
- [ ] Limite de fichas aumentado

### Google Drive (Premium)
- [ ] Autorização Google funciona
- [ ] Arquivos salvos no Google Drive
- [ ] Sincronização funciona

### Relatórios
- [ ] Gráficos carregam
- [ ] Dados corretos
- [ ] Exportação PDF funciona
- [ ] Impressão funciona

---

## 📊 Performance e SEO

### Performance
- [ ] Lighthouse score > 80
- [ ] Tempo de carregamento < 3s
- [ ] Sem erros de console
- [ ] Sem memory leaks

### SEO
- [ ] Meta tags corretas
- [ ] Open Graph tags
- [ ] Sitemap.xml
- [ ] robots.txt

### Segurança
- [ ] HTTPS ativado
- [ ] Security headers corretos
- [ ] CORS configurado
- [ ] Rate limiting ativado

---

## 📝 Documentação

### Arquivos
- [ ] README.md completo
- [ ] DEPLOY_NETLIFY.md detalhado
- [ ] SETUP_NETLIFY.sh funcional
- [ ] .env.example com todas as variáveis
- [ ] Comentários no código

### Instruções
- [ ] Como fazer deploy
- [ ] Como configurar variáveis
- [ ] Como testar
- [ ] Como troubleshoot
- [ ] Como escalar

---

## 🔍 Monitoramento

### Logs
- [ ] Logs do Netlify acessíveis
- [ ] Logs do banco de dados acessíveis
- [ ] Logs do Stripe acessíveis
- [ ] Sem erros críticos

### Alertas
- [ ] Alertas de erro configurados
- [ ] Alertas de performance configurados
- [ ] Email de notificação configurado

### Backups
- [ ] Backup do banco de dados
- [ ] Backup do código
- [ ] Plano de recuperação de desastres

---

## 🚀 Lançamento

### Antes do Lançamento Público
- [ ] Todos os testes passando
- [ ] Documentação completa
- [ ] Suporte configurado
- [ ] Monitoramento ativo
- [ ] Backups em dia

### Após o Lançamento
- [ ] Monitorar erros
- [ ] Monitorar performance
- [ ] Coletar feedback dos usuários
- [ ] Planejar melhorias
- [ ] Atualizar documentação

---

## 📞 Suporte e Contato

### Documentação
- [ ] Documentação do usuário
- [ ] FAQ
- [ ] Guia de troubleshooting
- [ ] Vídeos tutoriais

### Suporte
- [ ] Email de suporte
- [ ] Chat de suporte
- [ ] Formulário de feedback
- [ ] Comunidade/Forum

---

## ✨ Checklist Final

- [ ] Todos os itens acima verificados
- [ ] Nenhum erro crítico
- [ ] Performance aceitável
- [ ] Segurança em dia
- [ ] Documentação completa
- [ ] Pronto para lançamento! 🎉

---

**Data de Verificação:** _______________

**Responsável:** _______________

**Observações:** 
```
[Adicione observações aqui]
```

---

**Última atualização: Fevereiro 2026**
